const { Client } = require('pg');

exports.handler = async (event) => {

    const client = new Client({
        user: 'superadmin',
        host: 'postgresql-serverless-private.cqmgmqd3kup1.us-east-2.rds.amazonaws.com',
        database: 'postgres',
        password: '74hiuvuVSaLNiBe',
        port: 5432,
        ssl: true
    });

    const responseHeaders = {
             'Access-Control-Allow-Origin': '*', // Replace with your app's domain
            'Access-Control-Allow-Methods': 'OPTIONS, POST, GET, DELETE, PUT',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        };

    try {
        // Determine the API Gateway resource and method to handle the request
        await client.connect(); // Connect to the RDS database
        const resource = event.resource;
        const httpMethod = event.httpMethod;
        //const routeKey = event.routeKey;
        // Set the CORS headers in the response
        
        
        if (httpMethod === 'GET' && resource === '/modifypolicy') {
            return { statusCode: 200, headers: responseHeaders, body: JSON.stringify('Modify Policy Page') };
        } else if (httpMethod === 'GET' && resource === '/updateaddress') {
            return { statusCode: 200, headers: responseHeaders, body: JSON.stringify('Address Update Page') };
        } else if (httpMethod === 'GET' && resource === '/updatevehicle') {
            return { statusCode: 200,headers: responseHeaders, body: JSON.stringify('Vehicle Information Page') };
        } else if (httpMethod === 'GET' && resource === '/updatedriver') {
            return { statusCode: 200, headers: responseHeaders, body: JSON.stringify('Driver Information Page') };
        } else if (httpMethod === 'GET' && resource === '/updatecoverage') {
            return { statusCode: 200, headers: responseHeaders, body: JSON.stringify('Coverage Information Page') };
        } else if (httpMethod === 'GET' && resource === '/home') {
            return { statusCode: 200,headers: responseHeaders, body: JSON.stringify('Home Page') };
        } 
        // else if (httpMethod === 'PUT' && resource === '/updateaddress/{id}') {
        //     const { id } = event.pathParameters.id;
        //     const { address, city, state, zip } = JSON.parse(event.body);

        //     try {
        //       const updateAddressQuery = {
        //         text: 'UPDATE users SET address=$1, city=$2, state=$3, zip=$4 WHERE id=$5',
        //         values: [address, city, state, zip, id],
        //       };
        //       await client.query(updateAddressQuery);
      
        //       return { statusCode: 200,headers: responseHeaders, body: JSON.stringify('Address updated successfully') };
        //     } catch (error) {
        //         console.error(error);
        //         return { statusCode: 500,headers: responseHeaders, body: JSON.stringify('Error updating address') };
        //     } finally {
        //         client.end();
        //     }
        // } 
        else if(httpMethod === 'PUT' && resource === '/updateaddress/{id}') {
            const id = event.pathParameters.id; // Extract 'id' from the path parameters
            const { address, city, state, zip } = JSON.parse(event.body);

            const updateAddressQuery = 'UPDATE users SET address=$1, city=$2, state=$3, zip=$4 WHERE id=$5';
            const updateresult = await client.query(updateAddressQuery,[address, city, state, zip, id]);
            return {
                statusCode: 200,
                headers: responseHeaders, // Include the CORS headers in the response
                body: JSON.stringify(
                    'Address updated successfully'
                ),
            };
        } 
        else if (httpMethod === 'GET' && resource === '/addresspreview/{id}') {
            const { id } = event.pathParameters.id;
      
            try {
                const user = await client.query('SELECT * FROM users WHERE id = $1', [id]);
                return { statusCode: 200,headers: responseHeaders, body: JSON.stringify(user.rows[0]) };
            } catch (error) {
                console.error(error);
                return { statusCode: 500, headers: responseHeaders, body: JSON.stringify('Error fetching address') };
            } finally {
                client.end();
            }
        } else if (httpMethod === 'PUT' && resource === '/addressupdate/{id}') {
            const { id } = event.pathParameters.id;
            const { address, city, state, zip } = JSON.parse(event.body);
      
            try {
                const updatedUser = await client.query(
                'UPDATE users SET address = $1, city = $2, state = $3, zip = $4 WHERE id = $5 RETURNING *',
                [address, city, state, zip, id]
                );
                return { statusCode: 200, headers: responseHeaders, body: JSON.stringify(updatedUser.rows[0]) };
            } catch (error) {
                console.error(error);
                return { statusCode: 500, headers: responseHeaders, body: JSON.stringify('Error updating address') };
            } finally {
              client.end();
            }
        } else if (httpMethod === 'POST' && resource === '/submit') {
            const {
              username,
              password,
              email,
              phone,
              address,
              city,
              state,
              zip,
            } = JSON.parse(event.body);
      
            try {
                const newUser = await client.query(
                    'INSERT INTO users (username, password, email, phone, address, city, state, zip) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
                    [username, password, email, phone, address, city, state, zip]
                );
                return { statusCode: 200, headers: responseHeaders, body: JSON.stringify(newUser.rows[0]) };
            } catch (error) {
                console.error(error);
                return { statusCode: 500,headers: responseHeaders,  body: JSON.stringify('Error creating user') };
            } finally {
                client.end();
            }
        } else if (httpMethod === 'POST' && resource === '/submitaddress') {
            const {
                effectiveDate,
                vehicleId,
                policyEffectiveDate,
            } = JSON.parse(event.body);
    
            if (new Date(effectiveDate) < new Date(policyEffectiveDate)) {
                return { statusCode: 400,headers: responseHeaders, body: JSON.stringify('Date cannot be prior to the Policy effective date') };
            }
        
            try {
                const result = await client.query(
                'INSERT INTO submissions (vehicle_id, effective_date, transaction_id, policy_effective_date) VALUES ($1, $2, $3, $4) RETURNING *',
                [
                    vehicleId,
                    effectiveDate,
                    Math.floor(10000000 + Math.random() * 90000000),
                    policyEffectiveDate,
                ]
                );
        
                return {
                    statusCode: 200,
					headers: responseHeaders,
                    body: JSON.stringify(`Address details are successfully captured. Transaction Id: ${result.rows[0].transaction_id}. To view the changes, go to the Home Page and click View Policy`),
                };
            } catch (error) {
                console.error(error);
                return { statusCode: 500, headers: responseHeaders, body: JSON.stringify('Error capturing address details') };
            } finally {
                client.end();
            }
        } else if (httpMethod === 'GET' && resource === '/back') {
            return { statusCode: 200, headers: responseHeaders, body: JSON.stringify('Navigated to Address Preview page') };
        } else if (httpMethod === 'GET' && resource === '/home') {
            return { statusCode: 200,headers: responseHeaders, body: JSON.stringify('Navigated to Home page') };
        } 
        // else if (httpMethod === 'GET' && resource === '/vehicle/{id}') {
        //     const { id } = event.pathParameters.id;
        //     const vehicle = await client.query('SELECT * FROM vehicles WHERE id = $1', [id]);
        //     return { statusCode: 200,headers: responseHeaders, body: JSON.stringify(vehicle.rows[0])}; } 
        else if (httpMethod === 'GET' && resource === '/vehicle/{id}') {
            const vehicleId = event.pathParameters.id; // Extract 'id' from the path parameters

            const vehicleQuery = 'SELECT * FROM vehicles WHERE user_id = $1';
            const vehicleResult = await client.query(vehicleQuery, [vehicleId]);
            const vehicles = vehicleResult.rows;

			
            return {
                statusCode: 200,
                headers: responseHeaders, // Include the CORS headers in the response
                body: JSON.stringify(
                    vehicles,
                ),
            };
        }
        else if (httpMethod === 'POST' && resource === '/vehicle') {
            const {
                user_id,
                vehicle_identification_number,
                year,
                make,
                model,
                body_style,
                ownership_status,
                ownership_duration,
                purchased_in_last_90_days,
                parking_location,
            } = JSON.parse(event.body);
            const newVehicle = await client.query(
                'INSERT INTO vehicles (user_id, vehicle_identification_number, year, make, model, body_style, ownership_status, ownership_duration, purchased_in_last_90_days, parking_location) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *',
                [
                user_id,
                vehicle_identification_number,
                year,
                make,
                model,
                body_style,
                ownership_status,
                ownership_duration,
                purchased_in_last_90_days,
                parking_location,
                ]
            );
            return { statusCode: 200, headers: responseHeaders, body: JSON.stringify(newVehicle.rows)};
        } 
        // else if (httpMethod === 'DELETE' && path === '/vehicle/{id}') {
        //     const { id } = event.pathParameters.id;
        //     await client.query('DELETE FROM vehicles WHERE id = $1', [id]);
        //     return { statusCode: 200, body: JSON.stringify('Vehicle was deleted!')};
        // } 
        else if (httpMethod === 'DELETE' && resource === '/vehicle') {
            const {vehicleIds} = JSON.parse(event.body);
            for(let i=0; i<vehicleIds.length; i++){
                await client.query('DELETE FROM vehicles WHERE id = $1', [vehicleIds[i]]);
            }
            return {
                statusCode: 200,
                headers: responseHeaders, // Include the CORS headers in the response
                body: JSON.stringify({"status":"vehicle deleted"},),
            };
            
        } 
        else if (httpMethod === 'POST' && resource === '/submitvehicle') {
            const { vehicle_id, effective_date, transaction_id, policy_effective_date } = JSON.parse(event.body);

            if (new Date(effective_date) < new Date(policy_effective_date)) {
                return { statusCode: 400,headers: responseHeaders,  body: JSON.stringify('Date cannot be prior to the Policy effective date')};
            } else {
                const result = await client.query(
                'INSERT INTO submissions (vehicle_id, effective_date, transaction_id, policy_effective_date) VALUES ($1, $2, $3, $4) RETURNING *',
                [vehicle_id, effective_date, transaction_id, policy_effective_date]
                );

                return { statusCode: 201,headers: responseHeaders,  body: JSON.stringify(`Vehicle details are successfully captured. Transaction Id: ${result.rows[0].transaction_id}`)};
            }
        } 
        else if (httpMethod === 'POST' && resource === '/submitcoverage') {
            const { vehicle_id, effective_date, transaction_id, policy_effective_date } = JSON.parse(event.body);

            if (new Date(effective_date) < new Date(policy_effective_date)) {
                return { statusCode: 400,headers: responseHeaders,  body: JSON.stringify('Date cannot be prior to the Policy effective date')};
            } else {
                const result = await client.query(
                'INSERT INTO submissions (vehicle_id, effective_date, transaction_id, policy_effective_date) VALUES ($1, $2, $3, $4) RETURNING *',
                [vehicle_id, effective_date, transaction_id, policy_effective_date]
                );

                return { statusCode: 201,headers: responseHeaders,  body: JSON.stringify(`Coverage details are successfully captured. Transaction Id: ${result.rows[0].transaction_id}`)};
            }
        }
        else if (httpMethod === 'GET' && resource === '/home') {
            return { statusCode: 200,headers: responseHeaders, body: JSON.stringify('Home Page')};
        } else if (httpMethod === 'GET' && resource === '/vehiclepreview') {
            return { statusCode: 200,headers: responseHeaders, body: JSON.stringify('Vehicle Preview Page')};
        }  else if (httpMethod === 'POST' && resource === '/driver') {
            const {
                user_id,
                first_name,
                last_name,
                date_of_birth,
                marital_status,
                date_licensed,
                license_state,
                gender,
                license_number,
                relationship_to_policyholder,
            } = JSON.parse(event.body);

            const newDriver = await client.query(
                'INSERT INTO drivers (user_id, first_name, last_name, date_of_birth, marital_status, date_licensed, license_state, gender, license_number, relationship_to_policyholder) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *',
                [
                user_id,
                first_name,
                last_name,
                date_of_birth,
                marital_status,
                date_licensed,
                license_state,
                gender,
                license_number,
                relationship_to_policyholder,
                ]
            );
            console.log("Add driver :",newDriver.rows);
            return { statusCode: 200,headers: responseHeaders, body: JSON.stringify(newDriver.rows)};
        } 
        // else if (routeKey === 'DELETE /driver/{id}') {
        //     const { id } = event.pathParameters.id;
        //     await client.query('DELETE FROM drivers WHERE id = $1', [id]);
        //     return { statusCode: 200, body: JSON.stringify('Driver was deleted!')};
        // } 
        else if (httpMethod === 'DELETE' && resource === '/driver') {
		const {driver_Ids_Arr}=  JSON.parse(event.body);
            // await client.query('DELETE FROM drivers WHERE id = $1', [id]);
            // return { statusCode: 200, body: JSON.stringify('Driver was deleted!')};
            //const driverIds = event.body.driver_Ids_Arr.map(id => +id);
            for(let i=0; i<driver_Ids_Arr.length; i++){
                await client.query('DELETE FROM drivers WHERE id = $1', [driver_Ids_Arr[i]]);
            }
            return { statusCode: 200, headers: responseHeaders, body: JSON.stringify('Drivers deleted successfully!') };
        }
        else if(httpMethod === 'GET' && resource === '/driver/{id}') {
            const driverId = event.pathParameters.id; // Extract 'id' from the path parameters

            console.log("Id paramete: ",driverId);
            const driverQuery = 'SELECT * FROM drivers WHERE user_id = $1';
            const driverResult = await client.query(driverQuery, [driverId]);
            const drivers = driverResult.rows;
            console.log("Driver details ",drivers);
            return {
                statusCode: 200,
                headers: responseHeaders, // Include the CORS headers in the response
                body: JSON.stringify(
                    drivers,
                ),
            };
        }
        else if (httpMethod === 'GET' && resource === '/driverpreview/{id}') {
            const driverId = event.pathParameters.id; // Extract 'id' from the path parameters

            console.log("Id paramete: ",driverId);
            const driverQuery = 'SELECT * FROM drivers WHERE user_id = $1';
            const driverResult = await client.query(driverQuery, [driverId]);
            const drivers = driverResult.rows;
            console.log("Driver details ",drivers);
            return {
                statusCode: 200,
                headers: responseHeaders, // Include the CORS headers in the response
                body: JSON.stringify(
                    drivers[0],
                ),
            };
        } else if (httpMethod === 'POST' && resource === '/driverinformation') {
            const {
                first_name,
                last_name,
                date_of_birth,
                marital_status,
                date_licensed,
                license_state,
                gender,
                license_number,
                relationship_to_policyholder,
            } = JSON.parse(event.body);
      
            const newDriver = await client.query(
                'INSERT INTO drivers (first_name, last_name, date_of_birth, marital_status, date_licensed, license_state, gender, license_number, relationship_to_policyholder) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *',
                [
                    first_name,
                    last_name,
                    date_of_birth,
                    marital_status,
                    date_licensed,
                    license_state,
                    gender,
                    license_number,
                    relationship_to_policyholder,
                ]
            );
      
            return { statusCode: 200,headers: responseHeaders, body: JSON.stringify(newDriver.rows[0]) };
        } else if (httpMethod === 'POST' && resource === '/submission') {
            const {
                vehicle_id,
                effective_date,
                transaction_id,
                policy_effective_date,
            } = JSON.parse(event.body);
    
            const newSubmission = await client.query(
            'INSERT INTO submissions (vehicle_id, effective_date, transaction_id, policy_effective_date) VALUES ($1, $2, $3, $4) RETURNING *',
            [vehicle_id, effective_date, transaction_id, policy_effective_date]
            );
    
            return { statusCode: 200, headers: responseHeaders, body: JSON.stringify(newSubmission.rows[0]) };
        } else if (httpMethod === 'POST' && resource === '/submitdriver') {
            const {
                vehicle_id,
                effective_date,
                policy_effective_date,
            } = JSON.parse(event.body);
    
            if (new Date(effective_date) < new Date(policy_effective_date)) {
                return { statusCode: 400, headers: responseHeaders, body: 'Date cannot be prior to the Policy effective date' };
            } else {
            const result = await client.query(
                'INSERT INTO submissions (vehicle_id, effective_date, transaction_id, policy_effective_date) VALUES ($1, $2, $3, $4) RETURNING *',
                [vehicle_id, effective_date, Math.floor(10000000 + Math.random() * 90000000), policy_effective_date]
            );
    
            return { statusCode: 201, 
					headers: responseHeaders,
                     body: JSON.stringify(`Driver details are successfully captured. Transaction Id: ${result.rows[0].transaction_id}`),
                   };
            }
        } else if (httpMethod === 'GET' && resource === '/coverage/{submission_id}') {
            const subid = event.pathParameters.submission_id; // Extract 'id' from the path parameters

            const coverageQuery = 'SELECT * FROM coverages WHERE submission_id = $1';
            const coverageResult = await client.query(coverageQuery, [subid]);
            const coverages = coverageResult.rows;
			
            return {
                statusCode: 200,
                headers: responseHeaders, // Include the CORS headers in the response
                body: JSON.stringify(
                    coverages,
                ),
            };
        } else if (httpMethod === 'PUT' && resource === '/coverage/{submission_id}') {
            const { submission_id } = event.pathParameters.submission_id;
            const {
                comprehensive,
                collision,
                roadside_assistance,
                full_glass_coverage,
                extended_transportation_expense,
                rideshare,
            } = JSON.parse(event.body);
    
            const result = await client.query(
            'UPDATE coverages SET comprehensive = $1, collision = $2, roadside_assistance = $3, \
            full_glass_coverage = $4, extended_transportation_expense = $5, rideshare = $6 WHERE \
            submission_id = $7',
            [
                comprehensive,
                collision,
                roadside_assistance,
                full_glass_coverage,
                extended_transportation_expense,
                rideshare,
                submission_id,
            ]
            );
    
            return { statusCode: 200,headers: responseHeaders, body: JSON.stringify(result.rows[0]) };
        } else if (httpMethod === 'GET' && resource === '/coveragepreview/{id}') {
            const { id } = event.pathParameters.id;
            const result = await client.query('SELECT * FROM coverages WHERE submission_id = $1',[id]);
    
            return { statusCode: 200,headers: responseHeaders, body: JSON.stringify(result.rows[0])};
        } else if (httpMethod === 'POST' && resource === '/coveragepreview/{id}/submit') {
            // Check if event.pathParameters exists and it has 'id' property
            if(event.pathParameters && event.pathParameters.id){
                const id = event.pathParameters.id;
                const result = await client.query('UPDATE submissions SET status = $1 WHERE id = $2', ['submitted', id]);
                return { statusCode: 200,headers: responseHeaders, body: JSON.stringify({ message: 'Submission successful' }) };
            }
            else{
                return {
					
                    statusCode: 404,
					headers: responseHeaders,
                    body: JSON.stringify({ error: 'Route not found' }),
                };
            }
            
        
            
        }
        else if(httpMethod === 'GET' && resource === '/cancellation/{id}') {
            const canid = event.pathParameters.id; // Extract 'id' from the path parameters
            const status = 'cancelled' ;
            const canQuery = 'SELECT * FROM policies WHERE user_id = $1 AND status != $2' ;
            const canResult = await client.query(canQuery,[canid,status]);
            const cans = canResult.rows;
            console.log("canellation details ",cans);
            return {
                statusCode: 200,
                headers: responseHeaders, // Include the CORS headers in the response
                body: JSON.stringify(
                    cans,
                ),
            };
        }
        //else if (httpMethod === 'GET' && resource === '/cancellation/{id}') {
           // const { id } = event.pathParameters.id;
            //const result = await client.query('SELECT * FROM policies WHERE user_id = $1', [id]);
            //return { statusCode: 200,headers: responseHeaders, body: JSON.stringify(result.rows) };
        //}
        else if (httpMethod === 'POST' && resource === '/cancellation') {
            const { user_id, policy_id, reason, talk_to_representative } = JSON.parse(event.body);
        
            if (!user_id || !policy_id || !reason || talk_to_representative === undefined) {
                return { statusCode: 400,
				headers: responseHeaders,
                        body: JSON.stringify('Please fill all the fields for successful Cancellation'),
                };
            } else {
                // await client.query('UPDATE policies SET status = $1 WHERE id = $2', ['cancelled', policy_id]);
                // return { statusCode: 200, body: JSON.stringify('Policy cancelled successfully') };
                const selectedPolicies= event.body.selectedPolicies;
                for(let i=0; i<selectedPolicies.length; i++){
                    await client.query('UPDATE policies SET status = $1 WHERE id = $2', ['cancelled', selectedPolicies[i]]);
                }
                return { statusCode: 200,headers: responseHeaders, body: JSON.stringify('Policy cancelled successfully') };
            }
        } else if (httpMethod === 'GET' && resource === '/cancellationpreview/{userId}') {
            const { userId } = event.pathParameters.userId;
            const result = await client.query(
                'SELECT * FROM policies WHERE user_id = $1 AND status = $2',
                [userId, 'active']
            );
            return { statusCode: 200,headers: responseHeaders, body: JSON.stringify(result.rows) };
        } else if (httpMethod === 'POST' && resource === '/cancellationpreview/{userId}') {
            const { userId } = event.pathParameters.userId;
            const { policyId, confirmCancellation } = JSON.parse(event.body);
        
            if (confirmCancellation) {
                await client.query('UPDATE policies SET status = $1 WHERE id = $2 AND user_id = $3', ['cancelled', policyId, userId]);
                return { statusCode: 200,headers: responseHeaders, body: JSON.stringify({ message: 'Policy cancelled successfully' })};
            } else {
                return { statusCode: 200, headers: responseHeaders, body: JSON.stringify({ message: 'Go back to the Cancellation page to select the correct Vehicle' })};
            }
        }
        /*else if (httpMethod === 'POST' && resource === '/submitcancellation') {
            const {
        //    vehicle_id,
        //    effective_date,
        //    transaction_id,
        //    policy_effective_date,
        //    } = JSON.parse(event.body);
        //        if (new Date(effective_date) < new Date(policy_effective_date)) {
        //        return { statusCode: 400,headers: responseHeaders, body: JSON.stringify('Date cannot be prior to the Policy effective date')};
        //    } else {
        //    const result = await client.query(
        //        'INSERT INTO submissions(vehicle_id, effective_date, transaction_id, policy_effective_date) VALUES($1, $2, $3, $4) RETURNING *',
        /*        [vehicle_id, effective_date, transaction_id, policy_effective_date]
            );
    
            return { statusCode: 201,
			headers: responseHeaders,
                        body: JSON.stringify(`Cancellation details are successfully captured. Transaction Id: ${result.rows[0].transaction_id}`),
                };
            }
        }*/
        else if (httpMethod === 'POST' && resource === '/coverage') {
    const {
        user_id,
        comprehensive,
        collision,
        roadside_assistance,
        full_glass_coverage,
        extended_transportation_expense,
        rideshare,
    } = JSON.parse(event.body);
    const newCoverage = await client.query(
        'INSERT INTO coverages (submission_id, comprehensive, collision, roadside_assistance, full_glass_coverage, extended_transportation_expense, rideshare) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
        [
            user_id,
            comprehensive,
            collision,
            roadside_assistance,
            full_glass_coverage,
            extended_transportation_expense,
            rideshare,
        ]
    );
    return { statusCode: 200,headers: responseHeaders, body: JSON.stringify(newCoverage.rows) };
}
        else if (httpMethod === 'POST' && resource === '/submitcancellation') {
            const {
            vehicle_id,
            effective_date,
            transaction_id,
            policy_effective_date,
            } = JSON.parse(event.body);
            if (new Date(effective_date) < new Date(policy_effective_date)) {

                return { statusCode: 400,headers: responseHeaders, body: JSON.stringify('Date cannot be prior to the Policy effective date')};
            } else {
            const result = await client.query(
                'INSERT INTO submissions(vehicle_id, effective_date, transaction_id, policy_effective_date) VALUES($1, $2, $3, $4) RETURNING *',
                [vehicle_id, effective_date, Math.floor(10000000 + Math.random() * 90000000), policy_effective_date]
            );
            console.log("submit cancellation :",result.rows);
            return {
                statusCode: 200,
                headers: responseHeaders,
                body: JSON.stringify("Cancellation details are successfully captured. Transaction Id:",),
                };
            }
        }
        else {
            return {
                statusCode: 404,
				headers: responseHeaders,
                body: JSON.stringify({ error: 'Route not found' }),
            };
        }
    } 
    catch (error) {
        console.error(error);
        return {
            statusCode: 500,
			headers: responseHeaders,
            body: JSON.stringify({ message: 'Internal Server Error' }),
        };
    } 
    finally {
        await client.end(); // Close the database connection
    }
};

//     const handleDeleteVehicle = async (event) => {
//     const { vehicle_Ids_Arr } = JSON.parse(event.body);
//     const ids = vehicle_Ids_Arr.map(id => +id);
  
//     try {
//       for (let i = 0; i < ids.length; i++) {
//         await client.query('DELETE FROM vehicles WHERE id = $1', [ids[i]]);
//       }
//       return {
//         statusCode: 200,
// 		headers: responseHeaders,
//         body: JSON.stringify('Vehicle was deleted!'),
//       };
//     } catch (error) {
//       console.error(error);
//       return {
//         statusCode: 500,
// 		headers: responseHeaders,
//         body: JSON.stringify({ message: 'Database error' }),
//       };
//     }
//   };