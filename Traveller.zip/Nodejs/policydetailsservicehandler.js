const { Client } = require('pg');

exports.handler = async (event) => {
    console.log('event', event);
    const client = new Client({
        user: 'superadmin',
        host: 'postgresql-serverless-private.cqmgmqd3kup1.us-east-2.rds.amazonaws.com',
        database: 'postgres',
        password: '74hiuvuVSaLNiBe',
        port: 5432,
        ssl: true
    });

    try {
        await client.connect(); // Connect to the RDS database
        const resource = event.resource;
        const httpMethod = event.httpMethod;

        // Set the CORS headers in the response
        const responseHeaders = {
            'Access-Control-Allow-Origin': '*', // Change this to your allowed origins
            'Access-Control-Allow-Methods': 'OPTIONS, GET',
            'Access-Control-Allow-Headers': 'Content-Type',
        };

        if (httpMethod === 'GET' && resource === '/policy/{id}') {
            const policyId = event.pathParameters.id; // Extract 'id' from the path parameters

            const policyQuery = 'SELECT * FROM policies WHERE user_id = $1';
            const policyResult = await client.query(policyQuery, [policyId]);
            const policy = policyResult.rows;

            if (!policy) {
                return {
                    statusCode: 404,
                    body: JSON.stringify({ error: 'Policy not found' }),
                };
            }

            const userQuery = 'SELECT * FROM users WHERE id = $1';
            const userResult = await client.query(userQuery, [policyId]);
            const user = userResult.rows;

            const vehicleQuery = 'SELECT * FROM vehicles WHERE user_id = $1';
            const vehicleResult = await client.query(vehicleQuery, [policyId]);
            const vehicles = vehicleResult.rows;

            const driverQuery = 'SELECT * FROM drivers WHERE user_id = $1';
            const driverResult = await client.query(driverQuery, [policyId]);
            const drivers = driverResult.rows;

            const coverageQuery = 'SELECT * FROM coverages WHERE submission_id = $1';
            const coverageResult = await client.query(coverageQuery, [policyId]);
            const coverages = coverageResult.rows;
			
            return {
                statusCode: 200,
                headers: responseHeaders, // Include the CORS headers in the response
                body: JSON.stringify({
                    policy,
                    user,
                    vehicles,
                    drivers,
                    coverages,
                }),
            };
        }


        else {
            return {
                statusCode: 404,
                headers: responseHeaders, // Include the CORS headers in the response
                body: JSON.stringify({ error: 'Route xyz not found' }),
            };
        }
    } catch (err) {
        console.error(err);
        return {
            statusCode: 500,
            headers: responseHeaders, // Include the CORS headers in the response
            body: JSON.stringify({ error: 'Internal server error' }),
        };
    } finally {
        await client.end(); // Close the database connection
    }
};
