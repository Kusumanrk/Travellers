const { Client } = require('pg');


exports.handler = async (event) => {
    
    const client = new Client({
        user: 'superadmin',
        host: 'postgresql-serverless-private.cqmgmqd3kup1.us-east-2.rds.amazonaws.com',
        database: 'postgres',
        password: '74hiuvuVSaLNiBe',
        port: 5432,
        ssl: true
    });


    try {
        // Determine the API Gateway resource and method to handle the request
        const resource = event.resource;
        const httpMethod = event.httpMethod;
        //const routeKey = event.routeKey;
        const responseHeaders = {
            'Access-Control-Allow-Origin': '*', // Change this to your allowed origins
            'Access-Control-Allow-Methods': 'OPTIONS, GET, POST',
            'Access-Control-Allow-Headers': 'Content-Type',
        };
    
        if (httpMethod === 'POST' && resource === '/home') {
            const response = {
                MyPoliciesPanel: {
                  updatePolicy: '/updatePolicy',
                  viewPolicy: '/viewPolicy',
                },
                ClaimsPanel: {
                  reportClaim: '/reportClaim',
                  viewExistingClaims: '/viewExistingClaims',
                },
                RenewalPanel: {
                  renewPolicy: '/renewPolicy',
                  autoRenewPolicy: '/autoRenewPolicy',
                }
            }
    
            return {
                statusCode: 200,
				headers: responseHeaders,
                body: JSON.stringify(response),
            };
        } 
        else if (httpMethod === 'GET') {
            // Handle other routes (e.g., /updatePolicy, /viewPolicy, etc.)
            return {
                statusCode: 200,
				headers: responseHeaders,
                body: JSON.stringify({ message: `Navigating to ${routeKey}` }),
            };
        }
        else {
            return {
                statusCode: 404,
				headers: responseHeaders,
                body: JSON.stringify({ error: 'Route not found' }),
            };
        }
    }
    catch (error) {
        console.error(error);
        return {
            statusCode: 500,
			headers: responseHeaders,
            body: JSON.stringify({ message: 'Internal Server Error' }),
        };
    }
};