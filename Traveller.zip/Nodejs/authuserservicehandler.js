const { Client } = require('pg');
// okta integration code
// const OktaJwtVerifier = require('@okta/jwt-verifier');

// const oktaJwtVerifier = new OktaJwtVerifier({
//     clientId: process.env.OIDC_CLIENT_ID,
//     issuer:  process.env.OIDC_ISSUER,
// });
// const authenticate = async (event) => {
//     const { headers } = event;
//     const authHeader = headers['Authorization'];
//     if (!authHeader) {
//         throw new Error('Authorization header is missing.');
//     }
    
//     const accessToken = authHeader.replace('Bearer ', '');

//     try {
//         await oktaJwtVerifier.verifyAccessToken(accessToken, 'api://default');
//     } catch (error) {
//         throw new Error('Invalid access token');
//     }
// };


exports.handler = async (event) => {
    const client = new Client({
        user: 'superadmin',
        host: 'postgresql-serverless-private.cqmgmqd3kup1.us-east-2.rds.amazonaws.com',
        database: 'postgres',
        password: '74hiuvuVSaLNiBe',
        port: 5432,
        ssl: true
    });

    try {
        await client.connect(); // Connect to the RDS database

        // Determine the API Gateway resource and method to handle the request
        const resource = event.resource;
        const httpMethod = event.httpMethod;
        const body = JSON.parse(event.body);

        // Set the CORS headers in the response
        const responseHeaders = {
            'Access-Control-Allow-Origin': '*', // Change this to your allowed origins
            'Access-Control-Allow-Methods': 'OPTIONS, POST, GET',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        };

        if (httpMethod === 'POST' && resource === '/register') {

            const { username, password, email, phone, address, city, state, zip } = body;
            //const hashedPassword = await bcrypt.hash(password, 10);
            const newUser = await client.query(
                'INSERT INTO users (username, password, email, phone, address, city, state, zip) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
                [username, password, email, phone, address, city, state, zip]
            );
    
            return {
                statusCode: 200,
                headers: responseHeaders,
                body: JSON.stringify(newUser.rows[0]),
            };
        } else if (resource === '/login' && httpMethod === 'POST') {
            // await authenticate(event); Uncomment this code for okta for enabling okta authentication
			const { username, password } = body;
            const user = await client.query('SELECT * FROM users WHERE username = $1', [username]);
            if (user.rows.length === 0 || password!==user.rows[0].password) {
                return {
                    statusCode: 401,
                    body: JSON.stringify({ message: 'Invalid Credential' }),
                };
            }

            return {
                statusCode: 200,
                headers: responseHeaders,
                body: JSON.stringify({ message: 'Logged in!' , "id": user.rows[0].id}),
            };
        } else if (resource === '/resetpassword' && httpMethod === 'POST') {
            const { email } = body;
            const user = await client.query('SELECT * FROM users WHERE email = $1', [email]);
            if (user.rows.length === 0) {
                return {
                statusCode: 401,
                body: JSON.stringify({ message: 'Invalid Email' }),
                };
            }

            return {
                statusCode: 200,
                headers: responseHeaders,
                body: JSON.stringify({ message: 'Check your email to reset your password!' }),
            };
        } else {
            return {
                statusCode: 404,
                headers: responseHeaders,
                body: JSON.stringify({ message: 'Resource not found.' }),
            };
        }
    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            headers: responseHeaders,
            body: JSON.stringify({ message: error }),
        };
    } finally {
        await client.end(); // Close the database connection
    }
};
