
-- Creating users table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(10) NOT NULL UNIQUE,
    address VARCHAR(255) NOT NULL,
    city VARCHAR(255) NOT NULL,
    state VARCHAR(2) NOT NULL,
    zip VARCHAR(5) NOT NULL
);

-- Creating vehicles table
CREATE TABLE vehicles (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    vehicle_identification_number VARCHAR(17) NOT NULL UNIQUE,
    year INT NOT NULL,
    make VARCHAR(255) NOT NULL,
    model VARCHAR(255) NOT NULL,
    body_style VARCHAR(255) NOT NULL,
    ownership_status VARCHAR(255) CHECK (ownership_status IN ('owned', 'leased')),
    ownership_duration VARCHAR(255) CHECK (ownership_duration IN ('<1 year', '2 to 3 years', '4 to 5 years', '>5 years')),
    purchased_in_last_90_days BOOLEAN,
    parking_location VARCHAR(255) CHECK (parking_location IN ('home garage', 'home on the road', 'not home')),
    lienholder_mortgagee_info VARCHAR(255),
    parking_info VARCHAR(255)
);

-- Creating submissions table
CREATE TABLE submissions (
    id SERIAL PRIMARY KEY,
    vehicle_id INT REFERENCES vehicles(id),
    effective_date DATE NOT NULL,
    transaction_id INT NOT NULL UNIQUE,
    policy_effective_date DATE NOT NULL
);

-- Creating drivers table
CREATE TABLE drivers (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    first_name VARCHAR(40) NOT NULL,
    last_name VARCHAR(40) NOT NULL,
    date_of_birth DATE NOT NULL,
    marital_status VARCHAR(255) CHECK (marital_status IN ('married', 'unmarried')),
    date_licensed DATE NOT NULL,
    license_state VARCHAR(255) NOT NULL,
    gender VARCHAR(255) CHECK (gender IN ('male', 'female')),
    license_number VARCHAR(255) NOT NULL,
    relationship_to_policyholder VARCHAR(255) CHECK (relationship_to_policyholder IN ('myself', 'spouse', 'child', 'other'))
);

-- Creating coverages table
CREATE TABLE coverages (
    id SERIAL PRIMARY KEY,
    submission_id INT REFERENCES submissions(id),
    comprehensive VARCHAR(255) CHECK (comprehensive IN ('100', '500', '1000', '3000', '5000')),
    collision VARCHAR(255) CHECK (collision IN ('100', '200', '300', '500', '1000')),
    roadside_assistance BOOLEAN,
    full_glass_coverage BOOLEAN,
    extended_transportation_expense VARCHAR(255) CHECK (extended_transportation_expense IN ('30/900', '40/1200', '50/1500')),
    rideshare BOOLEAN
);

-- Creating policies table
CREATE TABLE policies (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    submission_id INT REFERENCES submissions(id),
    status VARCHAR(255) CHECK (status IN ('active', 'cancelled')),
    premium_amount DECIMAL(10,2) NOT NULL,
    policy_start_date DATE NOT NULL,
    policy_end_date DATE NOT NULL
);

-- Inserting records into users table
INSERT INTO users (username, password, email, phone, address, city, state, zip) VALUES
('john_doe', '$2b$10$Nbq1IAmLny/rv96uiuAyD.wHmK2U.C3BVcyuy2oKuiZM9PQwYhsR2', 'john_doe@example.com', '1234567890', '123 Main St', 'New York', 'NY', '10001'),
('jane_doe', 'password456', 'jane_doe@example.com', '0987654321', '456 Broadway', 'Los Angeles', 'CA', '90001'),
('bob_smith', 'password789', 'bob_smith@example.com', '1122334455', '789 Park Ave', 'Chicago', 'IL', '60007'),
('alice_johnson', 'password321', 'alice_johnson@example.com', '5566778899', '321 Wall St', 'Houston', 'TX', '77002'),
('charlie_brown', 'password654', 'charlie_brown@example.com', '9988776655', '654 Madison Ave', 'Philadelphia', 'PA', '19019');

-- Inserting records into vehicles table
INSERT INTO vehicles (user_id, vehicle_identification_number, year, make, model, body_style, ownership_status, ownership_duration, purchased_in_last_90_days, parking_location, lienholder_mortgagee_info, parking_info) VALUES
(1, '1HGCM82633A123456', 2003, 'Honda', 'Accord', 'Sedan', 'owned', '4 to 5 years', false, 'home garage', 'Bank of America', 'Garage at home'),
(2, '1HGCM82633A123457', 2004, 'Toyota', 'Camry', 'Sedan', 'leased', '2 to 3 years', true, 'home on the road', 'Chase Bank', 'On the road at home'),
(3, '1HGCM82633A123458', 2005, 'Ford', 'Mustang', 'Coupe', 'owned', '>5 years', false, 'not home', 'Wells Fargo', 'Parking lot at work'),
(4, '1HGCM82633A123459', 2006, 'Chevrolet', 'Impala', 'Sedan', 'leased', '<1 year', true, 'home garage', 'Citi Bank', 'Garage at home'),
(5, '1HGCM82633A123460', 2007, 'Dodge', 'Charger', 'Sedan', 'owned', '4 to 5 years', false, 'home on the road', 'Bank of America', 'On the road at home');

-- Inserting records into submissions table
INSERT INTO submissions (vehicle_id, effective_date, transaction_id, policy_effective_date) VALUES
(1, '2022-01-01', 1001, '2022-01-01'),
(2, '2022-01-02', 1002, '2022-01-02'),
(3, '2022-01-03', 1003, '2022-01-03'),
(4, '2022-01-04', 1004, '2022-01-04'),
(5, '2022-01-05', 1005, '2022-01-05');

-- Inserting records into drivers table
INSERT INTO drivers (user_id, first_name, last_name, date_of_birth, marital_status, date_licensed, license_state, gender, license_number, relationship_to_policyholder) VALUES
(1, 'John', 'Doe', '1980-01-01', 'married', '2000-01-01', 'NY', 'male', 'NY123456', 'myself'),
(2, 'Jane', 'Doe', '1981-01-01', 'unmarried', '2001-01-01', 'CA', 'female', 'CA123456', 'myself'),
(3, 'Bob', 'Smith', '1982-01-01', 'married', '2002-01-01', 'IL', 'male', 'IL123456', 'myself'),
(4, 'Alice', 'Johnson', '1983-01-01', 'unmarried', '2003-01-01', 'TX', 'female', 'TX123456', 'myself'),
(5, 'Charlie', 'Brown', '1984-01-01', 'married', '2004-01-01', 'PA', 'male', 'PA123456', 'myself');

-- Inserting records into coverages table
INSERT INTO coverages (submission_id, comprehensive, collision, roadside_assistance, full_glass_coverage, extended_transportation_expense, rideshare) VALUES
(1, '500', '300', true, false, '30/900', false),
(2, '1000', '500', false, true, '40/1200', true),
(3, '3000', '1000', true, false, '50/1500', false),
(4, '5000', '100', false, true, '30/900', true),
(5, '100', '200', true, false, '40/1200', false);

-- Inserting records into policies table
INSERT INTO policies (user_id, submission_id, status, premium_amount, policy_start_date, policy_end_date) VALUES
(1, 1, 'active', 1000.00, '2022-01-01', '2023-01-01'),
(2, 2, 'cancelled', 1200.00, '2022-01-02', '2023-01-02'),
(3, 3, 'active', 1400.00, '2022-01-03', '2023-01-03'),
(4, 4, 'cancelled', 1600.00, '2022-01-04', '2023-01-04'),
(5, 5, 'active', 1800.00, '2022-01-05', '2023-01-05');