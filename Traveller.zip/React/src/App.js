
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { MyProvider } from './components/MyContext';

import Selfserviceloginpage from './components/Selfserviceloginpage';
import Selfservicehomepage from './components/Selfservicehomepage';
import Selfservicemodifypolicypage from './components/Selfservicemodifypolicypage';
import Selfserviceaddressupdatepage from './components/Selfserviceaddressupdatepage';
import Selfservicevehicleinformationpage from './components/Selfservicevehicleinformationpage';
import Vehiclesubmissionpage from './components/Vehiclesubmissionpage';
import Selfservicedriverinformationpage from './components/Selfservicedriverinformationpage';
import Selfservicecoverageinformationpage from './components/Selfservicecoverageinformationpage';
import Cancellationpage from './components/Cancellationpage';
import Selfservicepolicydetailspage from './components/Selfservicepolicydetailspage';
import Header from './components/Header';
const App = () => {
    return (
		<MyProvider>
        <div className="app">
            <BrowserRouter>
                <div className='navBar'>
                    <Header/>
                </div>
                <Routes>
                    <Route path="/" element={<Selfserviceloginpage/>} />
					<Route path="/Selfservicehomepage" element={<Selfservicehomepage/>} />
					<Route path="/Selfservicemodifypolicypage" element={<Selfservicemodifypolicypage/>} />
					<Route path="/Selfserviceaddressupdatepage" element={<Selfserviceaddressupdatepage/>} />
					<Route path="/Selfservicevehicleinformationpage" element={<Selfservicevehicleinformationpage/>} />
					<Route path="/Vehiclesubmissionpage" element={<Vehiclesubmissionpage/>} />
					<Route path="/Selfservicedriverinformationpage" element={<Selfservicedriverinformationpage/>} />
					<Route path="/Selfservicecoverageinformationpage" element={<Selfservicecoverageinformationpage/>} />
					<Route path="/Cancellationpage" element={<Cancellationpage/>} />
					<Route path="/Selfservicepolicydetailspage" element={<Selfservicepolicydetailspage/>} />
                </Routes>
            </BrowserRouter>
        </div>
		</MyProvider>
    );
};
export default App;
