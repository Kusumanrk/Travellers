import React, { useEffect, useState } from 'react';
import {useNavigate} from 'react-router-dom'
import { Pane, Button } from 'evergreen-ui';
import { useMyContext } from './MyContext';

const App = () => {

  const navigate = useNavigate();
  const { loggedin_Id } = useMyContext();

  useEffect(() => {
    console.log('loggedin_Id', loggedin_Id)
  }, [])

  const handleClick = (url) => {
    navigate(url)
  };

  return (
    <>
      <div style={{ display: 'flex', justifyContent: 'space-around' }}>        
      <Pane key="MyPoliciesPanel" elevation={1} width={500} padding={16} marginBottom={16}>
        <h2>My Policies</h2>
        <div key="updatePolicy" className="flexContainerRow" style={{ marginBottom: '8px' }}>
          <Button width='12rem' appearance="primary" onClick={() => handleClick('/Selfservicemodifypolicypage')}>
            Update Policy
          </Button>
        </div>
        <div key="viewPolicy" className="flexContainerRow" style={{ marginBottom: '8px' }}>
          <Button width='12rem' appearance="primary" onClick={() => handleClick('/Selfservicepolicydetailspage')}>
            View Policy
          </Button>
        </div>
      </Pane>
      <Pane key="ClaimsPanel" elevation={1} width={500} padding={16} marginBottom={16}>
        <h2>My Claims</h2>
        <div key="reportClaim" className="flexContainerRow" style={{ marginBottom: '8px' }}>
          <Button width='12rem' appearance="primary" onClick={() => handleClick('/Selfservicehomepage')} disabled>
          Report Claim
          </Button>
        </div>
        <div key="viewExistingClaims" className="flexContainerRow" style={{ marginBottom: '8px' }}>
          <Button width='12rem' appearance="primary" onClick={() => handleClick('/Selfservicehomepage')} disabled>
          view Existing Claims
          </Button>
        </div>
      </Pane>
      <Pane key="RenewalPanel" elevation={1} width={500} padding={16} marginBottom={16}>
        <h2>Renewal Panel</h2>
        <div key="renewPolicy" className="flexContainerRow" style={{ marginBottom: '8px' }}>
          <Button width='12rem' appearance="primary" onClick={() => handleClick('/Selfservicehomepage')} disabled>
          Renew Policy
          </Button>
        </div>
        <div key="autoRenewPolicy" className="flexContainerRow" style={{ marginBottom: '8px' }}>
          <Button width='12rem' appearance="primary" onClick={() => handleClick('/Selfservicehomepage')} disabled>
          Auto Renew Policy
          </Button>
        </div>
      </Pane>
      </div>
    </>
  );
};

export default App;
