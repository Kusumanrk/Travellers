import React from 'react';
import { Button, Pane } from 'evergreen-ui';
import { useNavigate } from 'react-router-dom';

const ModifyPolicy = () => {

  const navigate = useNavigate();

  const navigateTo = (url) => {
    navigate(url)
  };

  return (
    <>
      <Pane style={{ display: 'flex', flexWrap: 'wrap', gap: '5rem', justifyContent: 'center', maxWidth: '60vw', margin: 'auto' }} padding={16}>
        <div className="flexContainerRow" marginBottom={8}>
          <Button width='22rem' height='3rem' onClick={() => navigateTo('/Selfserviceaddressupdatepage')} appearance="primary" >
            Update Address
          </Button>
        </div>
        <div className="flexContainerRow" marginBottom={8}>
          <Button width='22rem' height='3rem' onClick={() => navigateTo('/Selfservicevehicleinformationpage')} appearance="primary" >
            Update Vehicle
          </Button>
        </div>
        <div className="flexContainerRow" marginBottom={8}>
          <Button width='22rem' height='3rem' onClick={() => navigateTo('/Selfservicedriverinformationpage')} appearance="primary" >
            Update Driver
          </Button>
        </div>
        <div className="flexContainerRow" marginBottom={8}>
          <Button width='22rem' height='3rem' onClick={() => navigateTo('/Selfservicecoverageinformationpage')} appearance="primary" >
            Update Coverage
          </Button>
        </div>
        <div className="flexContainerRow" marginBottom={8}>
          <Button width='22rem' height='3rem' onClick={() => navigateTo('/Cancellationpage')} appearance="primary" >
            Cancel Policy
          </Button>
        </div>
        <div className="flexContainerRow" marginBottom={8}>
          <Button width='22rem' height='3rem' onClick={() => navigateTo('/Selfservicepolicydetailspage')} appearance="primary" >
            View Policy
          </Button>
        </div>
      </Pane>
      <div style={{display:'flex', justifyContent: 'center', margin:'2rem'}}>
        <Button width= '10rem' onClick={() => navigateTo('/Selfservicehomepage')} appearance="default">
          Back
        </Button>
      </div>
    </>
  );
};

export default ModifyPolicy;