import React, { useEffect, useState } from 'react';
import { TextInputField, Button, Pane, TextInput, Checkbox } from 'evergreen-ui';
import { useMyContext } from './MyContext';
import { useNavigate } from 'react-router-dom';

const VehicleInfo = () => {
  const { loggedin_Id } = useMyContext();
  const [isAddButtonDisabled, setisAddButtonDisabled] = useState(false);
  const [isRemoveButtonDisabled, setIsRemoveButtonDisabled] = useState(true);
  const [sectionEnabled, setSectionEnabled] = useState({});
  const [existingVehicle, setExistingVehicle] = useState([])
  const [showNewVehicleSection, setShowNewVehicleSection] = useState(false)
  const [showVehicleUpdate, setShowVehicleUpdate] = useState(true)
  const [showVehiclePreview, setShowVehiclePreview] = useState(false)
  const [effectiveDate, setEffectiveDate] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [showVehicleSubmission, setShowVehicleSubmission] = useState(false)
  const [vehicles, setVehicles] = useState([]);
  const [vin, setVin] = useState('');
  const [year, setYear] = useState('');
  const [make, setMake] = useState('');
  const [model, setModel] = useState('');
  const [bodyStyle, setBodyStyle] = useState('');
  const [ownershipStatus, setOwnershipStatus] = useState('owned');
  const [ownershipDuration, setOwnershipDuration] = useState('2 to 3 years');
  const [purchasedInLast90Days, setPurchasedInLast90Days] = useState(false);
  const [parkingLocation, setParkingLocation] = useState('home garage');

  const navigate = useNavigate();

  useEffect(() => {
    // fetch(`http://localhost:3000/vehicle/${loggedin_Id}`)
    fetch(`${process.env.REACT_APP_PLATFORM_URL}/vehicle/${loggedin_Id}`)
      .then((res) => res.json())
      .then(data => {
        setExistingVehicle(data)
      })
  }, [])

  const handleSectionShow = (value) => {
    if (value === 'update') {
      setShowVehicleUpdate(true);
      setShowVehiclePreview(false);
      setShowVehicleSubmission(false);
    }
    else if (value === 'preview') {
      setShowVehicleUpdate(false);
      setShowVehiclePreview(true);
      setShowVehicleSubmission(false);
    }
    else if (value === 'submit') {
      setShowVehicleUpdate(false);
      setShowVehiclePreview(false);
      setShowVehicleSubmission(true);
    }
  }

  function checkForTrueValue() {
    for (const key in sectionEnabled) {
      if (sectionEnabled[key] === true) {
        return true; // If any property is true, return true
      }
    }
    return false; // If no property is true, return false
  }

  function getIdsforSelectedCheckBox() {
    const idsArr = [];
    for (const key in sectionEnabled) {
      if (sectionEnabled[key] === true) {
        idsArr.push(key);
      }
    }
    let newArr = idsArr.map(Number);
    return newArr;
  }

  useEffect(() => {
    const hasTrueValue = checkForTrueValue();
    hasTrueValue ? setIsRemoveButtonDisabled(false) : setIsRemoveButtonDisabled(true)
  }, [sectionEnabled])

  const handleSubmit = async () => {
    // const response = await fetch('http://localhost:3000/submit-vehicle', {
    const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/submitvehicle`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        vehicle_id: 1,
        effective_date: effectiveDate,
        transaction_id: Math.floor(10000000 + Math.random() * 90000000),
        policy_effective_date: '2023-09-25',
      }),
    });

    if (response.ok) {
      await addVehicle();
      const data = await response.text();
      setMessage(data);
      setError('');
    } else {
      const error = await response.text();
      setError(error);
      setMessage('');
    }
  };

  const addVehicle = async () => {
    if (!vin || !year || !make || !model || !bodyStyle) {
      alert('Please fill all the required fields');
      return;
    }
    // const response = await fetch('http://localhost:3000/vehicle', {
    const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/vehicle`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        user_id: loggedin_Id,
        vehicle_identification_number: vin,
        year,
        make,
        model,
        body_style: bodyStyle,
        ownership_status: ownershipStatus,
        ownership_duration: ownershipDuration,
        purchased_in_last_90_days: purchasedInLast90Days,
        parking_location: parkingLocation,
      }),
    });
    const data = await response.json();
    // setVehicles([...vehicles, data]);
    if (data.length > 0) {
      alert("Vehicle Added SuccessFully")
      navigate('/Vehiclesubmissionpage')
    }
  };

  const removeVehicle = async (id) => {
    // await fetch(`http://localhost:3000/vehicle`, {
    await fetch(`${process.env.REACT_APP_PLATFORM_URL}/vehicle`, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            vehicleIds: getIdsforSelectedCheckBox()
        }) // Convert the request body to JSON format
    })
    .then(res => res.json())
    .then(data => {
        if (data.status) {
            alert("Vehicle deleted successfully, please visit the policy page to check.");
        }
    });
    // setVehicles(vehicles.filter((vehicle) => vehicle.id !== id));
};


  return (
    <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
      <Pane width='42vw'>
        {showVehicleUpdate &&
          <Pane className="container">
            <Pane>
              <h1>Vehicle Update Page</h1>
            </Pane>
            <Pane display="flex" flexDirection="row" justifyContent="right" marginTop="2rem" gap="20px">
              <Button width='8rem' appearance="primary" disabled={isAddButtonDisabled} onClick={() => { setShowNewVehicleSection(true); setisAddButtonDisabled(true) }}>Add vehicle</Button>
              <Button width='8rem' appearance="primary" disabled={isRemoveButtonDisabled} onClick={removeVehicle}> Remove Vehicle</Button>
            </Pane>
            {showNewVehicleSection &&
              <>
                <h2>Add New Vehicle</h2>
                <div className="flexContainerRow" marginBottom={8}>
                  <TextInputField
                    label="Vehicle Identification Number"
                    value={vin}
                    onChange={(e) => setVin(e.target.value)}
                    placeholder="Vehicle Identification Number"
                  />
                  <TextInputField
                    label="Year"
                    value={year}
                    onChange={(e) => setYear(e.target.value)}
                    placeholder="Year"
                  />
                  <TextInputField
                    label="Make"
                    value={make}
                    onChange={(e) => setMake(e.target.value)}
                    placeholder="Make"
                  />
                  <TextInputField
                    label="Model"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    placeholder="Model"
                  />
                  <TextInputField
                    label="Body Style"
                    value={bodyStyle}
                    onChange={(e) => setBodyStyle(e.target.value)}
                    placeholder="Body Style"
                  />
                </div>
              </>
            }
            {existingVehicle &&
              <>
                <h2>Existing Vehicle</h2>
                {existingVehicle.map((vehicle, index) =>
                  <Pane marginTop="10px" marginBottom="2rem">
                    <Pane marginBottom="1rem">
                      <h3>Vehicle {index + 1}</h3>
                      <hr />
                    </Pane>
                    <Checkbox
                      label="Select this section"
                      checked={sectionEnabled[vehicle.id] || false}
                      onChange={() => {
                        setSectionEnabled((prevSectionEnabled) => {
                          return {
                            ...prevSectionEnabled,
                            [vehicle.id]: !prevSectionEnabled[vehicle.id],
                          };
                        });
                      }}
                    />
                    <TextInputField readOnly
                      label="Vehicle Identification Number"
                      value={vehicle.vehicle_identification_number}
                      // onChange={(e) => setVin(e.target.value)}
                      placeholder="Vehicle Identification Number"
                      marginRight={8}
                    />
                    <TextInputField readOnly
                      label="Year"
                      value={vehicle.year}
                      // onChange={(e) => setYear(e.target.value)}
                      placeholder="Year"
                      marginRight={8}
                    />
                    <TextInputField readOnly
                      label="Make"
                      value={vehicle.make}
                      // onChange={(e) => setMake(e.target.value)}
                      placeholder="Make"
                      marginRight={8}
                    />
                    <TextInputField readOnly
                      label="Model"
                      value={vehicle.model}
                      // onChange={(e) => setModel(e.target.value)}
                      placeholder="Model"
                      marginRight={8}
                    />
                    <TextInputField readOnly
                      label="Body Style"
                      value={vehicle.body_style}
                      // onChange={(e) => setBodyStyle(e.target.value)}
                      placeholder="Body Style"
                      marginRight={8}
                    />
                  </Pane>
                )}
              </>
            }
            {/* <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="2rem">
            <Button width='8rem' onClick={() => navigate('/Selfservicemodifypolicypage')}>Back</Button>
            {showNewVehicleSection && <Button width='8rem' onClick={addVehicle}>Next</Button>}
          </Pane> */}
            <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="4rem" marginBottom="4rem">
              <Button width='8rem' onClick={() => navigate('/Selfservicemodifypolicypage')}>Back</Button>
              {showNewVehicleSection && <Button width='8rem' onClick={() => handleSectionShow('preview')}>Preview</Button>}
            </Pane>
          </Pane>
        }
        {showVehiclePreview &&
          <Pane>
            <>
              <Pane>
                <h1>Vehicle Preview Page</h1>
              </Pane>
              <h2>New Vehicle</h2>
              <Pane>
                <TextInputField readOnly
                  label="Vehicle Identification Number"
                  value={vin}
                  // onChange={(e) => setVin(e.target.value)}
                  placeholder="Vehicle Identification Number"
                />
                <TextInputField readOnly
                  label="Year"
                  value={year}
                  // onChange={(e) => setYear(e.target.value)}
                  placeholder="Year"
                />
                <TextInputField readOnly
                  label="Make"
                  value={make}
                  // onChange={(e) => setMake(e.target.value)}
                  placeholder="Make"
                />
                <TextInputField readOnly
                  label="Model"
                  value={model}
                  // onChange={(e) => setModel(e.target.value)}
                  placeholder="Model"
                />
                <TextInputField readOnly
                  label="Body Style"
                  value={bodyStyle}
                  // onChange={(e) => setBodyStyle(e.target.value)}
                  placeholder="Body Style"
                />
              </Pane>
              <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="4rem" marginBottom="4rem">
                <Button width='8rem' onClick={() => handleSectionShow('update')}>Back</Button>
                <Button width='8rem' onClick={() => handleSectionShow('submit')}>Submit</Button>
              </Pane>
            </>
          </Pane>
        }
        {showVehicleSubmission &&
          <Pane className="container">
            <h1>Vehicle Submission Page</h1>
            <TextInputField
              label="Effective Date"
              id="effectiveDate"
              type="date"
              marginBottom={8}
              value={effectiveDate}
              onChange={(e) => setEffectiveDate(e.target.value)}
            />
            <div className="flexContainerRow" marginBottom={8}>
              <Button width='8rem' onClick={handleSubmit} appearance="primary" marginTop='10px'>
                Submit
              </Button>
            </div>
            <Pane marginTop='10px' marginBottom='10px'>
              {error && <div className="error">{error}</div>}
              {message && <div className="message">{message}</div>}
            </Pane>
            <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="2rem">
              <Button width='8rem' onClick={() => handleSectionShow('preview')} appearance="default">
                Back
              </Button>
              <Button width='8rem' onClick={() => navigate('/Selfservicehomepage')} appearance="default">
                Home
              </Button>
            </Pane>
          </Pane>
        }
      </Pane>
    </div>
  );
};

export default VehicleInfo;