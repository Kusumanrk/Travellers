import React, { createContext, useState, useContext } from 'react';

const MyContext = createContext();

export const MyProvider = ({ children }) => {
  const [loggedin_Id, setloggedin_Id] = useState(null);

  const updateLoggedin_Id = (newValue) => {
    setloggedin_Id(newValue);
  };

  return (
    <MyContext.Provider value={{ loggedin_Id, updateLoggedin_Id }}>
      {children}
    </MyContext.Provider>
  );
};

export const useMyContext = () => {
  return useContext(MyContext);
};
