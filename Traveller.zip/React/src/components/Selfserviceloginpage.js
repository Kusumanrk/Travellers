import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMyContext } from './MyContext';
import { TextInputField, Button, Link, Pane } from 'evergreen-ui'; // Import Link component from Evergreen

const App = () => {
  const { loggedin_Id, updateLoggedin_Id } = useMyContext();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [showRegistrationSection, setShowRegistrationSection] = useState(false); // State to manage visibility of optional fields
  const [showLoginSection, setShowLoginSection] = useState(true);
  const [showForgotPasswordSection, setShowForgotPasswordSection] = useState(false);
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zip, setZip] = useState('');

  const navigate = useNavigate();

  const handleLogin = async () => {
    // const response = await fetch('http://localhost:3000/login', {
    const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });
    const data = await response.json();
    if (data.message === 'Logged in!') {
      updateLoggedin_Id(data.id);
      navigate('/Selfservicehomepage')
    }
    else {
      alert(data)
    }
    console.log(data);
  };

  const handleRegister = async () => {
    // const response = await fetch('http://localhost:3000/register', {
    const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password, email, phone, address, city, state, zip }),
    });
    const data = await response.json();
    if (data !== 'Please Enter All The Details') {
      alert('Registration done successfully!')
    }
    else {
      alert(data)
    }
    console.log(data);
  };

  const handleResetPassword = async () => {
    // const response = await fetch('http://localhost:3000/reset-password', {
    const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/resetpassword`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email }),
    });
    const data = await response.json();
    alert(data)
    console.log(data);
  };

  const handleSectionShow = (value) => {
    if (value === 'login') {
      setShowLoginSection(true)
      setShowForgotPasswordSection(false)
      setShowRegistrationSection(false)
    }
    else if (value === 'register') {
      setShowLoginSection(false)
      setShowForgotPasswordSection(false)
      setShowRegistrationSection(true)
    }
    else if (value === 'forgotPassword') {
      setShowLoginSection(false)
      setShowForgotPasswordSection(true)
      setShowRegistrationSection(false)
    }
  }

  return (
    <div className="container" style={{display:'flex', flexDirection:'column', alignItems:'center'}}>
      <Pane width='40vw'>
      {(showLoginSection || showRegistrationSection) && (
        <>
          <div className="flexContainerRow">
            <label>Username</label>
            <TextInputField
              placeholder="Enter your username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
          <div className="flexContainerRow">
            <label>Password</label>
            <TextInputField
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          {showLoginSection && (
            <div className="flexContainerRow">
              <Button width='8rem' onClick={handleLogin}>Sign In</Button>
              <Link
                onClick={() => handleSectionShow('register')}
                marginRight={12}
                marginLeft={12}
                color="default"
                textDecoration="underline"
                cursor="pointer">
                Register
              </Link>
              <Link
                onClick={() => handleSectionShow('forgotPassword')}
                color="default"
                textDecoration="underline"
                cursor="pointer">
                Forgot Password
              </Link>
            </div>
          )}
        </>
      )}
      {(showForgotPasswordSection || showRegistrationSection) && (
        <>
          <div className="flexContainerRow">
            <label>Email</label>
            <TextInputField
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          {showForgotPasswordSection && (
            <> 
            <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="4rem" marginBottom="4rem">
            <Button width='8rem'
              onClick={handleResetPassword}
            >
              Submit
            </Button>
              <Button width='8rem'
                onClick={() => handleSectionShow('login')}
              >
                Back
              </Button>
              </Pane>
            </>
          )}
        </>
      )}
      {showRegistrationSection && (
        <>
          <div className="flexContainerRow">
            <label>Phone</label>
            <TextInputField
              placeholder="Enter your phone number"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
          <div className="flexContainerRow">
            <label>Address</label>
            <TextInputField
              placeholder="Enter your address"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
            />
          </div>
          <div className="flexContainerRow">
            <label>City</label>
            <TextInputField
              placeholder="Enter your city"
              value={city}
              onChange={(e) => setCity(e.target.value)}
            />
          </div>
          <div className="flexContainerRow">
            <label>State</label>
            <TextInputField
              placeholder="Enter your state"
              hint="State can have maximum 2 charcters."
              value={state}
              onChange={(e) => setState(e.target.value)}
            />
          </div>
          <div className="flexContainerRow">
            <label>Zip Code</label>
            <TextInputField
              placeholder="Enter your zip code"
              hint="Zip Code should not contain more than 5 digits"
              value={zip}
              onChange={(e) => setZip(e.target.value)}
            />
          </div>
          <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="4rem" marginBottom="4rem">
          <Button width='8rem' onClick={handleRegister}>
            Register
          </Button>
          <Button width='8rem' onClick={() => handleSectionShow('login')}>
            Back
          </Button>
          </Pane>
        </>

      )}
      </Pane>
    </div>
  );
};

export default App;
