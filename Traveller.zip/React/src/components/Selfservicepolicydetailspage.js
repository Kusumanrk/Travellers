import React, { useEffect, useState } from 'react';
import { Button, Pane, TextInput, majorScale, TextInputField, SelectField } from 'evergreen-ui';
import { useMyContext } from './MyContext';
import { useNavigate } from 'react-router-dom';

const PolicyDetails = () => {
  const { loggedin_Id } = useMyContext();
  const [policyDetails, setPolicyDetails] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchPolicyDetails();
  }, [])

  const fetchPolicyDetails = async () => {
    try {
      // const response = await fetch(`http://localhost:3000/policy/${loggedin_Id}`, {
      const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/policy/${loggedin_Id}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json();
      setPolicyDetails(data);
    } catch (error) {
      console.error('Error fetching policy details:', error);
    }
  };

  return (
    <div style={{display:'flex', flexDirection:'column', justifyContent: 'center', alignItems:'center'}}>
    <Pane width='42vw'>
    <Pane className="container">
      {policyDetails && (
        <>
        <h1>View Policy Page</h1>
          <h2>Address:</h2>
          <Pane>
            <TextInputField readOnly
              label="Address"
              value={policyDetails.user[0].address}
            />
            <TextInputField readOnly
              label="City"
              value={policyDetails.user[0].city}
            />
            <SelectField readOnly
              label="State"
              value={policyDetails.user[0].state}
              style={{background: "white"}}
            >
              <option value="CA">California</option>
              <option value="NY">New York</option>
            </SelectField>
            <TextInputField readOnly
              label="Zip"
              value={policyDetails.user[0].zip}
            />
          </Pane>
          <Pane marginBottom={majorScale(2)}>
            <h2>Vehicles:</h2>
            {policyDetails.vehicles.map((vehicle, index) => (
              <>
                <h4>Vehicle {index + 1}</h4>
                <TextInputField readOnly
              label="Make"
              value={vehicle.make}
            />
            <TextInputField readOnly
              label="Model"
              value={vehicle.model}
            />
            <TextInputField readOnly
              label={`Body Style`}
              value={vehicle.body_style}
            />
            <TextInputField readOnly
              label={`year`}
              value={vehicle.year}
            />
            <TextInputField readOnly
              label={`Vehicle Identification Number
              `}
              value={vehicle.vehicle_identification_number}
            />
              </>
            ))}
          </Pane>
          <Pane className="flexContainerColumn" marginBottom={majorScale(2)}>
            <h2>Drivers:</h2>
            {policyDetails.drivers.map((driver, index) => (
              <div>
                {`Driver ${index+1}`}
                <hr />
                <TextInputField readOnly
              label={`Driver Name`}
              value={`${driver.first_name} ${driver.last_name}`}
            />
            <TextInputField readOnly
              type="date"
              label={`DOB`}
              value={driver.date_of_birth.toString().split('T')[0]}
            />
            <TextInputField readOnly
              type="date"
              label={`License Date`}
              value={driver.date_licensed.toString().split('T')[0]}
            />
            <TextInputField readOnly
              label={`License number`}
              value={driver.license_number}
            />
            <TextInputField readOnly
              label={`License State`}
              value={driver.license_state
              }
            />
            <TextInputField readOnly
              label={`Marital Status`}
              value={driver.marital_status
              }
            />
            <TextInputField readOnly
              label={`Relationship To Policyholder`}
              value={driver.relationship_to_policyholder
              }
            />
              </div>
            ))}
          </Pane>
          <Pane className="flexContainerRow" marginBottom={majorScale(2)}>
            <h2>Coverages:</h2>
            {policyDetails.coverages.map((coverage, index) => (
              <>
                <h4>Coverage {index + 1}</h4>
                <TextInputField readOnly
              label="Comprehensive"
              value={coverage.comprehensive}
            />
            <TextInputField readOnly
              label="Collision"
              value={coverage.collision}
            />
            <TextInputField readOnly
              label="Rideshare"
              value={coverage.rideshare}
            />
            <TextInputField readOnly
              label="Roadside Assistance"
              value={coverage.roadside_assistance}
            />
              </>
            ))}
            {/* <label>Coverages:</label>
              <TextInput value={policyDetails.coverages.comprehensive} readOnly />
              <TextInput value={policyDetails.coverages.collision} readOnly />
              <TextInput value={policyDetails.coverages.rideshare} readOnly />
              <TextInput value={policyDetails.coverages.roadside_assistance} readOnly /> */}
          </Pane>
          <Pane className="flexContainerRow" marginBottom={majorScale(2)}>
            <h2>Policies:</h2>
            {policyDetails.policy.map((plcy, index) => (
              <>
                <h4>Policy {index + 1}</h4>
                <TextInputField readOnly
              label="Premium Amount"
              value={plcy.premium_amount}
            /><TextInputField readOnly
            label="Status"
            value={plcy.status}
          />
          <TextInputField readOnly
              type="date"
              label={`Policy Start Date`}
              value={plcy.policy_start_date.toString().split('T')[0]}
            />
          <TextInputField readOnly
              type="date"
              label={`Policy End Date`}
              value={plcy.policy_end_date.toString().split('T')[0]}
            />
              </>
            ))}
          </Pane>
          <Pane display="flex" flexDirection="row" justifyContent="right" marginTop="4rem" marginBottom="4rem">
            <Button onClick={() => navigate('/Selfservicehomepage')} width="8rem" appearance="default">
              Home
            </Button>
          </Pane>
        </>
      )}
    </Pane>
    </Pane>
    </div>
      
    
  );
};

export default PolicyDetails;