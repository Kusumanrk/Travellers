import React from 'react';
import { Pane, Button } from 'evergreen-ui';
import { useNavigate } from 'react-router-dom';
import { useMyContext } from './MyContext';

const Header = () => {
    const { loggedin_Id, updateLoggedin_Id } = useMyContext();
    const navigate = useNavigate();
    const logout=()=> {
        updateLoggedin_Id(null)
        navigate('/')
    }

    return (
        <>
            <Pane display='flex' alignItems='center' justifyContent='center'>
                <h1>Self Service Policy Portal</h1>
                {loggedin_Id && <Button style={{width: "8rem", position:"absolute", right:'10px', cursor: "pointer"}} onClick={logout}>Logout</Button>}
            </Pane>
        </>
    )
}

export default Header