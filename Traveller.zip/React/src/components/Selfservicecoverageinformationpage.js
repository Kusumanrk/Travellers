import React, { useState, useEffect } from 'react';
import { Button, Pane, Radio, SelectField, TextInputField } from 'evergreen-ui';
import { useMyContext } from './MyContext';
import { useNavigate } from 'react-router-dom';

const CoverageInformation = () => {
  const { loggedin_Id } = useMyContext();
  const [existingCovergae, setExistingCoverage] = useState([])
  const [showCoverageUpdate, setShowCoverageUpdate] = useState(true)
  const [showCoveragePreview, setShowCoveragePreview] = useState(false)
  const [showCoverageSubmission, setShowCoverageSubmission] = useState(false)
  const [effectiveDate, setEffectiveDate] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [comprehensive, setComprehensive] = useState('100');
  const [collision, setCollision] = useState('100');
  const [roadsideAssistance, setRoadsideAssistance] = useState('Yes');
  const [fullGlassCoverage, setFullGlassCoverage] = useState('Yes');
  const [extendedTransportationExpense, setExtendedTransportationExpense] = useState('30/900');
  const [rideshare, setRideshare] = useState('Yes');
  // const [submissionId, setSubmissionId] = useState(1);

  const navigate = useNavigate();

  useEffect(() => {
    fetchCovergae()
  }, [])

  const fetchCovergae = async () => {
    // const response = await fetch(`http://localhost:3000/coverage/${loggedin_Id}`, {
    const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/coverage/${loggedin_Id}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });
    const data = await response.json();
    setExistingCoverage(data);
  };

  const handleSubmit = async () => {
    // const response = await fetch('http://localhost:3000/submit-vehicle', {
    const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/submitcoverage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        vehicle_id: 1,
        effective_date: effectiveDate,
        transaction_id: Math.floor(10000000 + Math.random() * 90000000),
        policy_effective_date: '2023-09-25',
      }),
    });

    if (response.ok) {
      await addCoverage();
      const data = await response.text();
      setMessage(data);
      setError('');
    } else {
      const error = await response.text();
      setError(error);
      setMessage('');
    }
  };

  const addCoverage = async () => {
    try {
      if (!comprehensive || !collision || !roadsideAssistance || !fullGlassCoverage || !extendedTransportationExpense || !rideshare) {
        alert('Please fill all the required fields');
        return;
      }
      // const response = await fetch('http://localhost:3000/coverage', {
      const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/coverage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_id: loggedin_Id,
          comprehensive,
          collision,
          roadside_assistance: roadsideAssistance === 'Yes' ? true : false,
          full_glass_coverage: fullGlassCoverage === 'Yes' ? true : false,
          extended_transportation_expense: extendedTransportationExpense,
          rideshare: rideshare === 'Yes' ? true : false,
        }),
      });
      const data = await response.json();
      if (data.length > 0) {
        alert('Coverage added successfully.')
      }
    } catch (error) {
      console.error('Error updating coverage:', error);
    }
  };

  const handleSectionShow = (value) => {
    if (value === 'update') {
      setShowCoverageUpdate(true);
      setShowCoveragePreview(false);
      setShowCoverageSubmission(false);
    }
    else if (value === 'preview') {
      setShowCoverageUpdate(false);
      setShowCoveragePreview(true);
      setShowCoverageSubmission(false);
    }
    else if (value === 'submit') {
      setShowCoverageUpdate(false);
      setShowCoveragePreview(false);
      setShowCoverageSubmission(true);
    }
  }

  return (
    <>
      <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
        <Pane width='42vw'>
          {showCoverageUpdate && <>
            <Pane className="container">
              <Pane>
                <h1>Coverage Information Page</h1>
              </Pane>
              <h2>Add Coverage</h2>
              <SelectField
                label="Comprehensive"
                value={comprehensive}
                onChange={(e) => setComprehensive(e.target.value)}
                marginBottom={16}
              >
                <option value="100">100</option>
                <option value="500">500</option>
                <option value="1000">1000</option>
                <option value="3000">3000</option>
                <option value="5000">5000</option>
              </SelectField>
              <SelectField
                label="Collision"
                value={collision}
                onChange={(e) => setCollision(e.target.value)}
                marginBottom={16}
              >
                <option value="100">100</option>
                <option value="200">200</option>
                <option value="300">300</option>
                <option value="500">500</option>
                <option value="1000">1000</option>
              </SelectField>
              <div className="flexContainerRow" marginBottom={16}>
                <label>Roadside Assistance</label>
                <Radio
                  label="Yes"
                  value="Yes"
                  checked={roadsideAssistance === 'Yes'}
                  onChange={(e) => setRoadsideAssistance(e.target.value)}
                  marginRight={16}
                />
                <Radio
                  label="No"
                  value="No"
                  checked={roadsideAssistance === 'No'}
                  onChange={(e) => setRoadsideAssistance(e.target.value)}
                />
              </div>
              <div className="flexContainerRow" marginBottom={16}>
                <label>Full Glass Coverage</label>
                <Radio
                  label="Yes"
                  value="Yes"
                  checked={fullGlassCoverage === 'Yes'}
                  onChange={(e) => setFullGlassCoverage(e.target.value)}
                  marginRight={16}
                />
                <Radio
                  label="No"
                  value="No"
                  checked={fullGlassCoverage === 'No'}
                  onChange={(e) => setFullGlassCoverage(e.target.value)}
                />
              </div>
              <SelectField
                label="Extended Transportation Expense"
                value={extendedTransportationExpense}
                onChange={(e) => setExtendedTransportationExpense(e.target.value)}
                marginBottom={16}
              >
                <option value="30/900">30/900</option>
                <option value="40/1200">40/1200</option>
                <option value="50/1500">50/1500</option>
              </SelectField>
              <div className="flexContainerRow" marginBottom={16}>
                <label>Rideshare</label>
                <Radio
                  label="Yes"
                  value="Yes"
                  checked={rideshare === 'Yes'}
                  onChange={(e) => setRideshare(e.target.value)}
                  marginRight={16}
                />
                <Radio
                  label="No"
                  value="No"
                  checked={rideshare === 'No'}
                  onChange={(e) => setRideshare(e.target.value)}
                />
              </div>
            </Pane>
            {existingCovergae &&
              <>
                <h2>Existing Coverages</h2>
                {existingCovergae.map((Coverage, index) =>

                  <Pane marginTop="10px" marginBottom="2rem">
                    <Pane marginBottom="1rem">
                    <h3>Coverage {index + 1}</h3>
                    <hr />
                    </Pane>
                    <SelectField readOnly
                      label="Comprehensive"
                      value={Coverage.comprehensive}
                      // onChange={(e) => setComprehensive(e.target.value)}
                      marginBottom={16}
                    >
                      <option value="100">100</option>
                      <option value="500">500</option>
                      <option value="1000">1000</option>
                      <option value="3000">3000</option>
                      <option value="5000">5000</option>
                    </SelectField>
                    <SelectField readOnly
                      label="Collision"
                      value={Coverage.collision}
                      // onChange={(e) => setCollision(e.target.value)}
                      marginBottom={16}
                    >
                      <option value="100">100</option>
                      <option value="200">200</option>
                      <option value="300">300</option>
                      <option value="500">500</option>
                      <option value="1000">1000</option>
                    </SelectField>
                    <div className="flexContainerRow" marginBottom={16}>
                      <label>Roadside Assistance</label>
                      <Radio readOnly
                        label="Yes"
                        value="Yes"
                        checked={(Coverage.roadside_assistance ? 'Yes' : 'No') === 'Yes'}
                        // onChange={(e) => setRoadsideAssistance(e.target.value)}
                        marginRight={16}
                      />
                      <Radio readOnly
                        label="No"
                        value="No"
                        checked={(Coverage.roadside_assistance ? 'Yes' : 'No') === 'No'}
                      // onChange={(e) => setRoadsideAssistance(e.target.value)}
                      />
                    </div>
                    <div className="flexContainerRow" marginBottom={16}>
                      <label>Full Glass Coverage</label>
                      <Radio readOnly
                        label="Yes"
                        value="Yes"
                        checked={(Coverage.full_glass_coverage ? 'Yes' : 'No') === 'Yes'}
                        // onChange={(e) => setFullGlassCoverage(e.target.value)}
                        marginRight={16}
                      />
                      <Radio readOnly
                        label="No"
                        value="No"
                        checked={(Coverage.full_glass_coverage ? 'Yes' : 'No') === 'No'}
                      // onChange={(e) => setFullGlassCoverage(e.target.value)}
                      />
                    </div>
                    <SelectField readOnly
                      label="Extended Transportation Expense"
                      value={Coverage.extendedTransportationExpense}
                      // onChange={(e) => setExtendedTransportationExpense(e.target.value)}
                      marginBottom={16}
                    >
                      <option value="30/900">30/900</option>
                      <option value="40/1200">40/1200</option>
                      <option value="50/1500">50/1500</option>
                    </SelectField>
                    <div className="flexContainerRow" marginBottom={16}>
                      <label>Rideshare</label>
                      <Radio readOnly
                        label="Yes"
                        value="Yes"
                        checked={(Coverage.rideshare ? 'Yes' : 'No') === 'Yes'}
                        // onChange={(e) => setRideshare(e.target.value)}
                        marginRight={16}
                      />
                      <Radio readOnly
                        label="No"
                        value="No"
                        checked={(Coverage.rideshare ? 'Yes' : 'No') === 'No'}
                      // onChange={(e) => setRideshare(e.target.value)}
                      />
                    </div>
                  </Pane>


                )}
              </>
            }
            <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="4rem" marginBottom="4rem">
              <Button width="8rem" onClick={() => navigate('/Selfservicemodifypolicypage')}>Back</Button>
              <Button width="8rem" onClick={() => handleSectionShow('preview')} >Preview</Button>
            </Pane>
          </>}
          {showCoveragePreview &&
            <>
              <Pane className="container">
                <Pane>
                  <h1>Coverage Preview Page</h1>
                </Pane>
                <h2>New Coverage</h2>
                <SelectField readOnly
                  label="Comprehensive"
                  value={comprehensive}
                  // onChange={(e) => setComprehensive(e.target.value)}
                  marginBottom={16}
                >
                  <option value="100">100</option>
                  <option value="500">500</option>
                  <option value="1000">1000</option>
                  <option value="3000">3000</option>
                  <option value="5000">5000</option>
                </SelectField>
                <SelectField readOnly
                  label="Collision"
                  value={collision}
                  // onChange={(e) => setCollision(e.target.value)}
                  marginBottom={16}
                >
                  <option value="100">100</option>
                  <option value="200">200</option>
                  <option value="300">300</option>
                  <option value="500">500</option>
                  <option value="1000">1000</option>
                </SelectField>
                <div className="flexContainerRow" marginBottom={16}>
                  <label>Roadside Assistance</label>
                  <Radio readOnly
                    label="Yes"
                    value="Yes"
                    checked={roadsideAssistance === 'Yes'}
                    // onChange={(e) => setRoadsideAssistance(e.target.value)}
                    marginRight={16}
                  />
                  <Radio readOnly
                    label="No"
                    value="No"
                    checked={roadsideAssistance === 'No'}
                  // onChange={(e) => setRoadsideAssistance(e.target.value)}
                  />
                </div>
                <div className="flexContainerRow" marginBottom={16}>
                  <label>Full Glass Coverage</label>
                  <Radio readOnly
                    label="Yes"
                    value="Yes"
                    checked={fullGlassCoverage === 'Yes'}
                    // onChange={(e) => setFullGlassCoverage(e.target.value)}
                    marginRight={16}
                  />
                  <Radio readOnly
                    label="No"
                    value="No"
                    checked={fullGlassCoverage === 'No'}
                  // onChange={(e) => setFullGlassCoverage(e.target.value)}
                  />
                </div>
                <SelectField readOnly
                  label="Extended Transportation Expense"
                  value={extendedTransportationExpense}
                  // onChange={(e) => setExtendedTransportationExpense(e.target.value)}
                  marginBottom={16}
                >
                  <option value="30/900">30/900</option>
                  <option value="40/1200">40/1200</option>
                  <option value="50/1500">50/1500</option>
                </SelectField>
                <div className="flexContainerRow" marginBottom={16}>
                  <label>Rideshare</label>
                  <Radio readOnly
                    label="Yes"
                    value="Yes"
                    checked={rideshare === 'Yes'}
                    // onChange={(e) => setRideshare(e.target.value)}
                    marginRight={16}
                  />
                  <Radio readOnly
                    label="No"
                    value="No"
                    checked={rideshare === 'No'}
                  // onChange={(e) => setRideshare(e.target.value)}
                  />
                </div>
                <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="4rem" marginBottom="4rem">
                  <Button width='8rem' onClick={() => handleSectionShow('update')}>Back</Button>
                  <Button width='8rem' onClick={() => handleSectionShow('submit')} >Submit</Button>
                </Pane>
              </Pane>
            </>
          }
          {showCoverageSubmission &&
            <Pane className="container">
              <h1>Covergae Submission Page</h1>
              <TextInputField
                label="Effective Date"
                id="effectiveDate"
                type="date"
                marginBottom={8}
                value={effectiveDate}
                onChange={(e) => setEffectiveDate(e.target.value)}
              />
              <div className="flexContainerRow" marginBottom={8}>
                <Button width='8rem' onClick={handleSubmit} appearance="primary" marginTop='10px'>
                  Submit
                </Button>
              </div>
              <Pane marginTop='10px' marginBottom='10px'>
                {error && <div className="error">{error}</div>}
                {message && <div className="message">{message}</div>}
              </Pane>
              <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="2rem">
                <Button width='8rem' onClick={() => handleSectionShow('preview')} appearance="default">
                  Back
                </Button>
                <Button width='8rem' onClick={() => navigate('/Selfservicehomepage')} appearance="default">
                  Home
                </Button>
              </Pane>
            </Pane>
          }
        </Pane>
      </div>
    </>
  );
};

export default CoverageInformation;