import React, { useEffect, useState } from 'react';
import { useMyContext } from './MyContext';
import { useNavigate } from 'react-router-dom';
import {
  Pane,
  Button,
  Text,
  TextInput,
  Checkbox,
  SelectField,
  Label,
  Radio,
  toaster,
  majorScale,
  minorScale,
  TextInputField
} from 'evergreen-ui';

const CancellationPage = () => {
  const { loggedin_Id } = useMyContext();
  const [policies, setPolicies] = useState([]);
  const [showCancellationUpdate, setShowCancellationUpdate] = useState(true)
  const [showCancellationPreview, setShowCancellationPreview] = useState(false)
  const [showCancellationSubmission, setShowCancellationSubmission] = useState(false)
  const [selectedPolicies, setSelectedPolicies] = useState([]);
  const [selectedPolicies2, setSelectedPolicies2] = useState([]);
  const [reason, setReason] = useState('');
  const [talkToRep, setTalkToRep] = useState(false);
  const [effectiveDate, setEffectiveDate] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const id = 1;

  const navigate = useNavigate();

  const previewPagePolicyList = selectedPolicies;

  useEffect(() => {
    fetchPolicies();
  }, [])

  const fetchPolicies = async () => {
    try {
      // const response = await fetch(`http://localhost:3000/cancellation/${loggedin_Id}`, {
      const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/cancellation/${loggedin_Id}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json();
      setPolicies(data);
    } catch (error) {
      console.error('Error fetching policies:', error);
    }
  };

  const handleCancelUpdateNext = () => {
    if (!reason || selectedPolicies.length === 0) {
      alert('Please fill all the required fields');
      return;
    }
    handleSectionShow('preview')
  }

  const togglePolicy = (policyId) => {
    if (selectedPolicies.includes(policyId)) {
      setSelectedPolicies(selectedPolicies.filter(id => id !== policyId));
      // setSelectedPolicies2(selectedPolicies.filter(id => id !== policyId))
    } else {
      setSelectedPolicies([...selectedPolicies, policyId]);
      // setSelectedPolicies2([...selectedPolicies, policyId])
    }
  };

  const handleSubmit = async () => {
    await cancelPolicy();
    try {
      // const response = await fetch('http://localhost:3000/submitCancellation', {
      const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/submitcancellation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          vehicle_id: 1,
          effective_date: effectiveDate,
          transaction_id: '9999999',
          policy_effective_date: '2022-01-01',
        }),
      });

      if (response.ok) {
        const data = await response.text();
        setMessage(data);
        setError('');
      } else {
        const errorText = await response.text();
        setError(errorText);
        setMessage('');
      }
    } catch (error) {
      console.error('Error submitting cancellation:', error);
      setError('Error submitting cancellation. Please try again.');
      setMessage('');
    }
  };

  const cancelPolicy = async () => {
    // if (!selectedPolicy || !reason || talkToRep === null) {
    //   setMessage('Please fill all the fields for successful Cancellation');
    //   return;
    // }

    try {
      // const response = await fetch('http://localhost:3000/cancellation', {
      const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/cancellation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ selectedPolicies }),
      });
      const data = await response.text();
      // setMessage(data);
      if(data === 'Policy cancelled successfully'){
        alert(data)
      }
    } catch (error) {
      console.error('Error cancelling policy:', error);
      toaster.danger('Error occurred while processing the cancellation.');
    }
  };

  const handleSectionShow = (value) => {
    if (value === 'update') {
      setShowCancellationUpdate(true);
      setSelectedPolicies(selectedPolicies2);
      setShowCancellationPreview(false);
      setShowCancellationSubmission(false);
    }
    else if (value === 'preview') {
      setShowCancellationUpdate(false);
      setSelectedPolicies2(selectedPolicies);
      setShowCancellationPreview(true);
      setShowCancellationSubmission(false);
    }
    else if (value === 'submit') {
      setShowCancellationUpdate(false);
      setShowCancellationPreview(false);
      setShowCancellationSubmission(true);
    }
  }

  return (
    <>
      {showCancellationUpdate &&
      <div style={{display:'flex', flexDirection:'column', justifyContent: 'center', alignItems:'center'}}>
      <Pane width='42vw'>
      <Pane className="container" padding={majorScale(2)}>
        <h1>Policy Cancellation Page</h1>
          <h2>Existing Policies</h2>
          {policies.map((policy,index) => (
            <Pane key={policy.id} marginBottom={minorScale(2)}>
              <Checkbox
                label={`Policy Number: ${index+1} Policy Period: ${policy.policy_start_date.toString().split('T')[0]} - ${policy.policy_end_date.toString().split('T')[0]} Premium Amount: $${policy.premium_amount}`}
                checked={selectedPolicies.includes(policy.id)} // Check if policy ID is in selectedPolicies array
                onChange={() => togglePolicy(policy.id)}
              />
            </Pane>
          ))}
          <SelectField
            label="Select a reason"
            value={reason}
            onChange={e => setReason(e.target.value)}
            marginBottom={minorScale(2)}
          >
            <option value="">Select a reason</option>
            <option value="Nonpayment of policy">Nonpayment of policy</option>
            <option value="Insured request">Insured request</option>
            <option value="Selling or no longer owning the car">Selling or no longer owning the car</option>
            <option value="Others">Others</option>
          </SelectField>
          <Label marginBottom={minorScale(2)}>
            Do you want to talk to our representatives before cancelling the policy?
          </Label>
          <Radio label="Yes" name="talkToRep" checked={talkToRep} onChange={() => setTalkToRep(true)} marginRight={minorScale(2)} />
          <Radio label="No" name="talkToRep" checked={!talkToRep} onChange={() => setTalkToRep(false)} />
          {talkToRep && (
            <p>
              Request you to reach out to our call center representative at xxx xxx xxxx to complete the transaction.
            </p>
          )}
          {talkToRep && (
            <Button marginTop={minorScale(2)}>
              Submit
            </Button>
          )}
          <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="4rem" marginBottom="4rem">
            <Button width="8rem" onClick={() => navigate('/Selfservicemodifypolicypage')}>Back</Button>
            <Button width="8rem" onClick={() => handleCancelUpdateNext()}>Preview</Button>
          </Pane>
        </Pane>
      </Pane>
      </div>
        }

      {showCancellationPreview &&
        <>
        <div style={{display:'flex', flexDirection:'column', justifyContent: 'center', alignItems:'center'}}>
      <Pane width='42vw'>
        <h1>Cancellation Preview Page</h1>
      <p>We are sorry to see you go. We will be sending you a mail shortly to complete the required formalities if any.</p>
          <p>We would like to re-confirm if you want to cancel the below-mentioned policy.</p>
          {policies.map((policy,index) => {
            if (selectedPolicies2.includes(policy.id)) {
              return (
                // <Pane key={policy.id} marginBottom={minorScale(2)} display='flex' alignItems='center' gap='2rem'>
                  <div style={{margin: "10px 0px"}}>
                  <div>{`Policy Number: ${index+1}`}</div>
                  <div> {`Policy Period: ${policy.policy_start_date.toString().split('T')[0]} - ${policy.policy_end_date.toString().split('T')[0]}`} </div>
                  <div>{`Premium Amount: $${policy.premium_amount}`}</div>
                  <Radio marginTop="1rem" label="Yes" name={`${policy.id}`} checked={selectedPolicies.includes(policy.id)} onChange={() => togglePolicy(policy.id)} marginRight={minorScale(2)} />
                  <Radio marginBottom="1rem" label="No" name={`${policy.id}`} checked={!selectedPolicies.includes(policy.id)} onChange={() => togglePolicy(policy.id)} />
                  <hr />
                  </div>
                // </Pane>
              )
            }
          })}
          <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="4rem" marginBottom="4rem">
            <Button width="8rem" onClick={() => handleSectionShow('update')}>Back</Button>
            <Button width="8rem" onClick={() => handleSectionShow('submit')} >Submit</Button>
          </Pane>
      </Pane>
      </div>
          
        </>
      }
      {showCancellationSubmission &&
      <div style={{display:'flex', flexDirection:'column', justifyContent: 'center', alignItems:'center'}}>
      <Pane width='42vw'>
      <Pane className="container">
          <h1>Cancellation Submission</h1>
          <Pane>
          <TextInputField
            label="Effective Date"
            type="date"
            value={effectiveDate}
            onChange={(e) => setEffectiveDate(e.target.value)}
            marginBottom={16}
          />
          </Pane>
          <Pane display="flex" marginTop={majorScale(2)}>
            <Button width="8rem" appearance='primary' marginTop="10px" marginRight={majorScale(2)} onClick={handleSubmit}>
              Submit
            </Button>
          </Pane>
          <Pane marginTop='10px' marginBottom='10px'>
          {error && <Text color="red">{error}</Text>}
          {message && <Text color="green">{message}</Text>}
          </Pane>
          <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="2rem">
            <Button width="8rem" onClick={() => handleSectionShow('preview')} >Back</Button>
            <Button width="8rem" onClick={() => navigate('/Selfservicehomepage')}>Home</Button>
          </Pane>
        </Pane>
      </Pane>
      </div>
        
        
      }
    </>
  );
};

export default CancellationPage;