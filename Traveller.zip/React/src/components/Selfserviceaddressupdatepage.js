import React, { useEffect, useState } from 'react';
import { useMyContext } from './MyContext';
import { TextInputField, Button, SelectField, Pane } from 'evergreen-ui';
import { useNavigate } from 'react-router-dom';

const AddressUpdate = () => {
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('CA');
  const [zip, setZip] = useState('');
  const [user, setUser] = useState({
    address: '',
    city: '',
    state: '',
    zip: ''
  });
  const [showAddressUpdate, setShowAddressUpdate] = useState(true)
  const [showAddressPreview, setShowAddressPreview] = useState(false)
  const [showAddressSubmission, setShowAddressSubmission] = useState(false)
  const { loggedin_Id, updateLoggedin_Id } = useMyContext();

  const [effectiveDate, setEffectiveDate] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const navigate = useNavigate();

  useEffect(() => {
    console.log(loggedin_Id)
  }, [])

  const handleSectionShow = (value) => {
    if (value === 'update') {
      setShowAddressUpdate(true);
      setShowAddressPreview(false);
      setShowAddressSubmission(false);
    }
    else if (value === 'preview') {
      setShowAddressUpdate(false);
      setShowAddressPreview(true);
      setShowAddressSubmission(false);
    }
    else if (value === 'submit') {
      setShowAddressUpdate(false);
      setShowAddressPreview(false);
      setShowAddressSubmission(true);
    }
  }


  const handleSubmit = async () => {
    // const response = await fetch('http://localhost:3000/submit-address', {
    const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/submitaddress`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        effectiveDate,
        vehicleId: 1, // This should be replaced with the actual vehicle id
        policyEffectiveDate: '2023-09-25', // This should be replaced with the actual policy effective date
      }),
    });

    if (response.ok) {
      await updateAddress();
      const message = await response.text();
      setMessage(message);
      setError('');
    } else {
      const error = await response.text();
      setError(error);
      setMessage('');
    }
  };

  const handleUpdateNext = () => {

    if (!address || !city || !state || !zip) {
      alert('Please fill all the required fields');
      return;
    }
    else {
      setUser({
        address: address,
        city: city,
        state: state,
        zip: zip
      })
    }

    handleSectionShow('preview')

  }
  const updateAddress = async () => {
    // const response = await fetch(`http://localhost:3000/updateAddress/${loggedin_Id}`, {
    const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/updateaddress/${loggedin_Id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ address, city, state, zip }),
    });

    const data = await response.json();

    if (response.ok) {
      alert("Address update successfully");
    } else {
      alert(data.message);
    }
  };




  return (
    <div style={{display:'flex', flexDirection:'column', justifyContent: 'center', alignItems:'center'}}>
      <Pane width='42vw'>
      {showAddressUpdate &&
        <div className="container">
          <h1>Address Update Page</h1>
          <TextInputField
            label="Address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
          />
          <TextInputField
            label="City"
            value={city}
            onChange={(e) => setCity(e.target.value)}
          />
          <SelectField
            label="State"
            value={state}
            onChange={(e) => setState(e.target.value)}
          >
            <option value="CA">California</option>
            <option value="NY">New York</option>
          </SelectField>
          <TextInputField
            label="Zip"
            hint="Zip Code should not contain more than 5 digits"
            value={zip}
            onChange={(e) => setZip(e.target.value)}
          />
          <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="4rem" marginBottom="4rem">
            <Button width='8rem' onClick={() => navigate('/Selfservicehomepage')}>
              Back
            </Button>
            <Button width='8rem' onClick={handleUpdateNext}>
              Preview
            </Button>
          </Pane>
        </div>
      }
      {showAddressPreview &&
        <Pane className="container">
          <h1>Address Preview</h1>
          <TextInputField disabled
            label="Address"
            value={user.address}
          />
          <TextInputField disabled
            label="City"
            value={user.city}
          />
          <SelectField read only
            label="State"
            value={user.state}
            style={{background: "white"}}
          >
            <option value="CA">California</option>
            <option value="NY">New York</option>
          </SelectField>
          <TextInputField disabled
            label="Zip"
            value={user.zip}
          />
          <Pane display="flex" flexDirection="row" justifyContent="space-between"  marginTop="4rem" marginBottom="4rem">
            <Button width='8rem' onClick={() => handleSectionShow('update')}>Back</Button>
            <Button width='8rem' onClick={() => handleSectionShow('submit')}>Submit</Button>
          </Pane>
        </Pane>
      }
      {showAddressSubmission &&
        <Pane className="container" padding={16}>
          <h1>Submission Page</h1>
          <TextInputField
            label="Effective Date"
            id="effectiveDate"
            type="date"
            marginBottom={8}
            value={effectiveDate}
            onChange={(e) => setEffectiveDate(e.target.value)}
          />
          <div className="flexContainerRow" marginBottom={8}>
            <Button width='8rem' onClick={handleSubmit} appearance="primary" marginTop='10px'>
              Submit
            </Button>
          </div>
          {error && <div className="error">{error}</div>}
          {message && <div className="message">{message}</div>}
          <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="2rem">
            <Button width='8rem' onClick={() => handleSectionShow('preview')} appearance="default">
              Back
            </Button>
            <Button width='8rem' onClick={() => navigate('/Selfservicehomepage')} appearance="default">
              Home
            </Button>
          </Pane>
        </Pane>
      }
      </Pane>
    </div>

  );
};

export default AddressUpdate;