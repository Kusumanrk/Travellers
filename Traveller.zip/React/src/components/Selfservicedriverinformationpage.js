import React, { useEffect, useState } from 'react';
import { TextInputField, SelectField, RadioGroup, Button, Pane, Checkbox } from 'evergreen-ui';
import { useMyContext } from './MyContext';
import { useNavigate } from 'react-router-dom';

const DriverInformation = () => {
  const { loggedin_Id } = useMyContext();
  const [drivers, setDrivers] = useState([]);
  const [existingDriver, setExistingDrivers] = useState([])
  const [sectionEnabled, setSectionEnabled] = useState({});
  const [isAddButtonDisabled, setIsAddButtonDisabled] = useState(false);
  const [isRemoveButtonDisabled, setIsRemoveButtonDisabled] = useState(true);
  const [showDriverUpdate, setShowDriverUpdate] = useState(true)
  const [showDriverPreview, setShowDriverPreview] = useState(false)
  const [showDriverSubmission, setShowDriverSubmission] = useState(false)
  const [showNewDriverSection, setShowNewDriverSection] = useState(false)
  const [effectiveDate, setEffectiveDate] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [driver, setDriver] = useState({
    user_id: loggedin_Id,
    first_name: '',
    last_name: '',
    date_of_birth: '',
    marital_status: 'married',
    date_licensed: '',
    license_state: '',
    gender: 'male',
    license_number: '',
    relationship_to_policyholder: 'myself'
  });

  const navigate = useNavigate();

  useEffect(() => {
    fetchDriver()
  }, [])

  const handleSectionShow = (value) => {
    if (value === 'update') {
      setShowDriverUpdate(true);
      setShowDriverPreview(false);
      setShowDriverSubmission(false);
    }
    else if (value === 'preview') {
      setShowDriverUpdate(false);
      setShowDriverPreview(true);
      setShowDriverSubmission(false);
    }
    else if (value === 'submit') {
      setShowDriverUpdate(false);
      setShowDriverPreview(false);
      setShowDriverSubmission(true);
    }
  }

  const handleUpdateNext = () => {
    if (!driver.first_name || !driver.last_name || !driver.date_of_birth || !driver.marital_status || !driver.date_licensed || !driver.license_state || !driver.gender || !driver.license_number || !driver.relationship_to_policyholder) {
      alert('Please fill all the required fields');
      return;
    }
    handleSectionShow('preview');
  }

  function checkForTrueValue() {
    for (const key in sectionEnabled) {
      if (sectionEnabled[key] === true) {
        return true;
      }
    }
    return false;
  }

  useEffect(() => {
    const hasTrueValue = checkForTrueValue();
    hasTrueValue ? setIsRemoveButtonDisabled(false) : setIsRemoveButtonDisabled(true)
  }, [sectionEnabled])

  const handleInputChange = (key, value) => {
    setDriver({ ...driver, [key]: value });
  };

  const handleSubmit = async () => {
    try {
      // const response = await fetch('http://localhost:3000/submit-driver', {
      const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/submitdriver`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          effective_date: effectiveDate,
          vehicle_id: 1,
          policy_effective_date: '2023-09-25',
        }),
      });

      if (response.ok) {
        await addDriver();
        const data = await response.text();
        setMessage(data);
        setError('');
      } else {
        const error = await response.text();
        setError(error);
        setMessage('');
      }
    } catch (error) {
      console.error('Error:', error);
      setError('An error occurred while submitting the form.');
      setMessage('');
    }
  };

  const fetchDriver = async () => {
    // const response = await fetch(`http://localhost:3000/driver/${loggedin_Id}`, {
    const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/driver/${loggedin_Id}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });
    const data = await response.json();
    setExistingDrivers(data);
  };

  const addDriver = async () => {
    // const response = await fetch('http://localhost:3000/driver', {
    const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/driver`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(driver)
    });
    const data = await response.json();
    // setDrivers([...drivers, data]);
    if (data.length > 0) {
      alert('Driver added successfully.')
    }
  };

  function getIdsforSelectedCheckBox() {
    const idsArr = [];
    for (const key in sectionEnabled) {
      if (sectionEnabled[key] === true) {
        idsArr.push(key);
      }
    }
    let newArr = idsArr.map(Number);
    return newArr;
  }

  const deleteDriver = async () => {
    // await fetch(`http://localhost:3000/driver`, {
    await fetch(`${process.env.REACT_APP_PLATFORM_URL}/driver`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        driver_Ids_Arr : getIdsforSelectedCheckBox()
      }),
    })
    .then(res => res.text())
    .then(data => {
        if (data) {
            alert("Driver deleted successfully, please visit the policy page to check.");
        }
    });;
  };

  return (
    <>
      {showDriverUpdate &&
        <div style={{display:'flex', flexDirection:'column', justifyContent: 'center', alignItems:'center'}}>
        <Pane width='42vw'>
        <>
          <h1>Driver Update Page</h1>
          <Pane display="flex" flexDirection="row" justifyContent="right" marginTop="2rem" gap="20px">
            <Button appearance="primary" disabled={isAddButtonDisabled} width="8rem" onClick={() =>{ setShowNewDriverSection(true); setIsAddButtonDisabled(true)}}>Add Driver</Button>
            <Button appearance="primary" disabled={isRemoveButtonDisabled} width="8rem" onClick={() => deleteDriver()}>Remove Driver</Button>
          </Pane>
          {showNewDriverSection &&
            <>
              <h1>Add New Driver</h1>
              <Pane className="container">
                <TextInputField
                  label="First Name"
                  value={driver.first_name}
                  onChange={(e) => handleInputChange('first_name', e.target.value)}
                />
                <TextInputField
                  label="Last Name"
                  value={driver.last_name}
                  onChange={(e) => handleInputChange('last_name', e.target.value)}
                />
                <TextInputField
                  label="Date of Birth"
                  type="date"
                  value={driver.date_of_birth}
                  onChange={(e) => handleInputChange('date_of_birth', e.target.value)}
                />
                <SelectField
                  label="Marital Status"
                  value={driver.marital_status}
                  onChange={(e) => handleInputChange('marital_status', e.target.value)}
                >
                  <option value="married">Married</option>
                  <option value="unmarried">Unmarried</option>
                </SelectField>
                <TextInputField
                  label="Date Licensed"
                  type="date"
                  value={driver.date_licensed}
                  onChange={(e) => handleInputChange('date_licensed', e.target.value)}
                />
                <TextInputField
                  label="License State"
                  value={driver.license_state}
                  onChange={(e) => handleInputChange('license_state', e.target.value)}
                />
                <RadioGroup
                  label="Gender"
                  value={driver.gender}
                  options={[
                    { label: 'Male', value: 'male' },
                    { label: 'Female', value: 'female' }
                  ]}
                  onChange={(e) => handleInputChange('gender', e.target.value)}
                />
                <TextInputField
                  label="License Number"
                  value={driver.license_number}
                  onChange={(e) => handleInputChange('license_number', e.target.value)}
                />
                <SelectField
                  label="Relationship to Policyholder"
                  value={driver.relationship_to_policyholder}
                  onChange={(e) => handleInputChange('relationship_to_policyholder', e.target.value)}
                >
                  <option value="myself">Myself</option>
                  <option value="spouse">Spouse</option>
                  <option value="child">Child</option>
                  <option value="other">Other</option>
                </SelectField>
              </Pane>
            </>}

          {existingDriver &&
            <>
              <h1>Existing Drivers</h1>
              {existingDriver.map((driver, index) =>
                <>
                  <h2>{`Driver ${index+1}`}</h2>
                  <hr />
                  <Checkbox
                    label="Select this section"
                    checked={sectionEnabled[driver.id] || false}
                    onChange={() => {
                      setSectionEnabled((prevSectionEnabled) => {
                        return {
                          ...prevSectionEnabled,
                          [driver.id]: !prevSectionEnabled[driver.id],
                        };
                      });
                    }}
                  />
                  <TextInputField readOnly
                    label="First Name"
                    value={driver.first_name}
                  />
                  <TextInputField readOnly
                    label="Last Name"
                    value={driver.last_name}
                  />
                  <TextInputField readOnly
                    label="Date of Birth"
                    type="date"
                    value={driver.date_of_birth.toString().split('T')[0]}
                  />
                  <SelectField readOnly
                    label="Marital Status"
                    value={driver.marital_status}
                  >
                    <option value="married">Married</option>
                    <option value="unmarried">Unmarried</option>
                  </SelectField>
                  <TextInputField readOnly
                    label="Date Licensed"
                    type="date"
                    value={driver.date_licensed.toString().split('T')[0]}
                  />
                  <TextInputField readOnly
                    label="License State"
                    value={driver.license_state}
                  />
                  <RadioGroup readOnly
                    label="Gender"
                    value={driver.gender}
                    options={[
                      { label: 'Male', value: 'male' },
                      { label: 'Female', value: 'female' }
                    ]}
                  />
                  <TextInputField readOnly
                    label="License Number"
                    value={driver.license_number}
                  />
                  <SelectField readOnly
                    label="Relationship to Policyholder"
                    value={driver.relationship_to_policyholder}
                  >
                    <option value="myself">Myself</option>
                    <option value="spouse">Spouse</option>
                    <option value="child">Child</option>
                    <option value="other">Other</option>
                  </SelectField>
                </>
              )}
            </>
          }

          
          <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="4rem" marginBottom="4rem">
            <Button width="8rem" onClick={() => navigate('/Selfservicemodifypolicypage')}>Back</Button>
            {showNewDriverSection && <Button width="8rem" onClick={handleUpdateNext}>Preview</Button>}
          </Pane>
        </>
          </Pane>
          </div>
      }
      {showDriverPreview &&
        <>
          {showNewDriverSection &&
            <>
            <div style={{display:'flex', flexDirection:'column', justifyContent: 'center', alignItems:'center'}}>
        <Pane width='42vw'>
        <h1>Driver Preview Page</h1>
              <Pane className="container">
                <TextInputField readOnly
                  label="First Name"
                  value={driver.first_name}
                />
                <TextInputField readOnly
                  label="Last Name"
                  value={driver.last_name}
                />
                <TextInputField readOnly
                  label="Date of Birth"
                  type="date"
                  value={driver.date_of_birth}
                />
                <SelectField readOnly
                  label="Marital Status"
                  value={driver.marital_status}
                >
                  <option value="married">Married</option>
                  <option value="unmarried">Unmarried</option>
                </SelectField>
                <TextInputField readOnly
                  label="Date Licensed"
                  type="date"
                  value={driver.date_licensed}
                />
                <TextInputField readOnly
                  label="License State"
                  value={driver.license_state}
                />
                <RadioGroup readOnly
                  label="Gender"
                  value={driver.gender}
                  options={[
                    { label: 'Male', value: 'male' },
                    { label: 'Female', value: 'female' }
                  ]}
                />
                <TextInputField readOnly
                  label="License Number"
                  value={driver.license_number}
                />
                <SelectField readOnly
                  label="Relationship to Policyholder"
                  value={driver.relationship_to_policyholder}
                >
                  <option value="myself">Myself</option>
                  <option value="spouse">Spouse</option>
                  <option value="child">Child</option>
                  <option value="other">Other</option>
                </SelectField>
              </Pane>
              <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="4rem" marginBottom="4rem">
            <Button width="8rem" onClick={() => handleSectionShow('update')}>Back</Button>
            <Button width="8rem" onClick={() => handleSectionShow('submit')}>Submit</Button>
          </Pane>
        </Pane>
        </div>
              
            </>}
          
        </>
      }
      {showDriverSubmission &&
      <div style={{display:'flex', flexDirection:'column', justifyContent: 'center', alignItems:'center'}}>
      <Pane width='42vw'>
      <Pane className="container" padding={16}>
          <h1>Driver Submission Page</h1>
          <TextInputField
            label="Effective Date"
            type="date"
            value={effectiveDate}
            onChange={(e) => setEffectiveDate(e.target.value)}
            marginBottom={16}
          />
          <Pane marginTop='10px' marginBottom='10px'>
          {error && <div className="error">{error}</div>}
          {message && <div className="message">{message}</div>}
          </Pane>
          <Button width="8rem" onClick={handleSubmit} appearance="primary" marginRight={8} marginTop="10px">
            Submit
          </Button>
          <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="4rem" marginBottom="4rem">
            <Button width="8rem" onClick={() => handleSectionShow('preview')} appearance="default">
              Back
            </Button>
            <Button width="8rem" onClick={() => navigate('/Selfservicemodifypolicypage')} appearance="default">
              Home
            </Button>
          </Pane>
        </Pane>
        </Pane>
        </div>
        
      }
    </>
  );
};

export default DriverInformation;