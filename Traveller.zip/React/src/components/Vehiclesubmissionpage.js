import React, { useState } from 'react';
import { TextInputField, Button, Pane } from 'evergreen-ui';
import { useNavigate } from 'react-router-dom';

const VehicleSubmissionPage = () => {
  const [effectiveDate, setEffectiveDate] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const navigate = useNavigate();

  const handleSubmit = async () => {
    // const response = await fetch('http://localhost:3000/submit-vehicle', {
    const response = await fetch(`${process.env.REACT_APP_PLATFORM_URL}/submitvehicle`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        vehicle_id: 1,
        effective_date: effectiveDate,
        transaction_id: Math.floor(10000000 + Math.random() * 90000000),
        policy_effective_date: '2023-09-25',
      }),
    });

    if (response.ok) {
      const data = await response.text();
      setMessage(data);
      setError('');
    } else {
      const error = await response.text();
      setError(error);
      setMessage('');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
      <Pane width='42vw'>
        <Pane className="container">
          <h1>Vehicle Submission Page</h1>
          <TextInputField
            label="Effective Date"
            id="effectiveDate"
            type="date"
            marginBottom={8}
            value={effectiveDate}
            onChange={(e) => setEffectiveDate(e.target.value)}
          />
          <div className="flexContainerRow" marginBottom={8}>
            <Button width='8rem' onClick={handleSubmit} appearance="primary" marginTop='10px'>
              Submit
            </Button>
          </div>
          <Pane marginTop='10px' marginBottom='10px'>
          {error && <div className="error">{error}</div>}
          {message && <div className="message">{message}</div>}
          </Pane>
          <Pane display="flex" flexDirection="row" justifyContent="space-between" marginTop="2rem">
            <Button width='8rem' onClick={() => navigate('/Selfservicevehicleinformationpage')} appearance="default">
              Back
            </Button>
            <Button width='8rem' onClick={() => navigate('/Selfservicehomepage')} appearance="default">
              Home
            </Button>
          </Pane>
        </Pane>
      </Pane>
    </div>
  );
};

export default VehicleSubmissionPage;